import React, { useState } from 'react';
import {
  HeartHandshake,
  CalendarCheck,
  CreditCard,
  Award,
  Phone,
  MessageSquare,
  AlertCircle,
  CheckCircle2,
  FileText,
  QrCode,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { storageService } from '../services/storageService';
import { Student, Receipt } from '../types';

interface ParentPortalViewProps {
  onOpenReceipt: (receipt: Receipt) => void;
  onOpenStudentQR: (studentId: string) => void;
}

export const ParentPortalView: React.FC<ParentPortalViewProps> = ({
  onOpenReceipt,
  onOpenStudentQR,
}) => {
  const { settings } = useSettings();
  const students = storageService.getStudents(false);
  const [selectedChildId, setSelectedChildId] = useState<string>(students[0]?.studentId || '');

  const child = students.find(s => s.studentId === selectedChildId) || students[0];
  const attendance = child ? storageService.getAttendanceForStudent(child.studentId) : [];
  const fees = child ? storageService.getFeesForStudent(child.studentId) : [];
  const receipts = child ? storageService.getReceipts().filter(r => r.studentId === child.studentId) : [];
  const exams = child ? storageService.getExamResults(child.studentId) : [];

  if (!child) {
    return <div className="p-8 text-center text-slate-500">No child records associated.</div>;
  }

  const outstandingFees = fees.filter(f => f.balance > 0);

  const handleWhatsAppAcademy = () => {
    const phoneClean = settings.phone.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Hello ${settings.academyName}, I am the parent of ${child.fullName} (${child.studentId}). I have an inquiry regarding academic progress.`
    );
    window.open(`https://wa.me/${phoneClean}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Parent Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 p-6 md:p-8 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4 text-left">
          <div className="w-16 h-16 rounded-2xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center">
            <HeartHandshake className="w-8 h-8 text-blue-300" />
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-1">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>Parent Transparency Portal</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black">
              Welcome, {child.parentName}
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Monitoring academic attendance, fee status & examinations for <strong>{child.fullName}</strong>
            </p>
          </div>
        </div>

        {/* Quick Contact & View Child QR */}
        <div className="flex flex-wrap gap-2.5 shrink-0">
          <button
            onClick={() => onOpenStudentQR(child.studentId)}
            className="flex items-center gap-2 rounded-xl bg-white text-slate-900 hover:bg-blue-50 px-4 py-2.5 text-xs font-bold transition shadow-md"
          >
            <QrCode className="w-4 h-4 text-blue-600" />
            <span>Child's QR ID</span>
          </button>

          <button
            onClick={handleWhatsAppAcademy}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 text-xs font-bold transition shadow-md"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat via WhatsApp</span>
          </button>
        </div>
      </div>

      {/* Child Switcher (if family has multiple kids) */}
      {students.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-bold text-slate-500 shrink-0">Select Child:</span>
          {students.slice(0, 3).map(s => (
            <button
              key={s.studentId}
              onClick={() => setSelectedChildId(s.studentId)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                s.studentId === child.studentId
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {s.fullName} ({s.grade})
            </button>
          ))}
        </div>
      )}

      {/* Live Attendance Notifications Stream */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <CalendarCheck className="w-4 h-4 text-emerald-600" />
          Real-Time Attendance Log (Entry & Class Verification)
        </h3>

        <div className="space-y-2">
          {attendance.length === 0 ? (
            <p className="text-xs text-slate-400 py-3">No attendance scans recorded for this term yet.</p>
          ) : (
            attendance.map(att => (
              <div
                key={att.attendanceId}
                className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-xs flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300 flex items-center justify-center font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">
                      {child.fullName} attended {att.className}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Verified at academy gate on {att.date} ({new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                    </p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-300">
                  {att.status}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Financial Standing & Receipts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tuition Fee Standing */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-purple-600" />
            Tuition Fee Ledger
          </h3>

          <div className="space-y-2.5">
            {fees.map(f => (
              <div
                key={f.feeId}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
              >
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">{f.billingMonth}</h4>
                  <p className="text-[11px] text-slate-500">
                    Tuition Fee: Rs. {f.amount.toLocaleString()} &bull; Balance Due: Rs. {f.balance.toLocaleString()}
                  </p>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  f.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                }`}>
                  {f.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Academic Remarks */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-500" />
            Teacher Evaluation & Term Marks
          </h3>

          <div className="space-y-2.5">
            {exams.map(ex => (
              <div
                key={ex.resultId}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white">{ex.examName}</span>
                  <span className="font-extrabold text-blue-600">{ex.percentage}% &bull; Grade {ex.gradeLetter}</span>
                </div>
                <p className="mt-1.5 text-[11px] text-slate-600 dark:text-slate-300 italic">
                  "{ex.teacherRemarks}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
