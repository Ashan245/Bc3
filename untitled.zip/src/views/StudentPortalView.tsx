import React, { useState } from 'react';
import {
  QrCode,
  CalendarCheck,
  CreditCard,
  GraduationCap,
  Award,
  BookOpen,
  FileText,
  Download,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { storageService } from '../services/storageService';
import { Receipt } from '../types';

interface StudentPortalViewProps {
  onOpenStudentQR: (studentId: string) => void;
  onOpenReceipt: (receipt: Receipt) => void;
}

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({
  onOpenStudentQR,
  onOpenReceipt,
}) => {
  const { currentUser } = useAuth();
  const { settings } = useSettings();

  // Target current student or demo student STU-000001
  const student = storageService.getStudentById(currentUser?.studentId || 'STU-000001') || storageService.getStudents(false)[0];
  const attendance = student ? storageService.getAttendanceForStudent(student.studentId) : [];
  const fees = student ? storageService.getFeesForStudent(student.studentId) : [];
  const receipts = student ? storageService.getReceipts().filter(r => r.studentId === student.studentId) : [];
  const exams = student ? storageService.getExamResults(student.studentId) : [];
  const materials = storageService.getLMSMaterials().filter(m => m.grade === student?.grade || m.grade === 'ALL');

  if (!student) {
    return <div className="p-8 text-center text-slate-500">Student record not found.</div>;
  }

  const attendanceRate = attendance.length > 0 ? 100 : 0; // or calculated against total scheduled sessions
  const pendingFees = fees.filter(f => f.balance > 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Student Welcome & QR Hero Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 md:p-8 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4 text-left">
          <img
            src={student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=140'}
            alt={student.fullName}
            className="w-20 h-20 rounded-2xl object-cover border-2 border-white/20 shadow-md"
          />
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-1">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>Student Academic Portal</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black">{student.fullName}</h2>
            <p className="text-xs text-blue-200 mt-0.5">
              ID: <strong>{student.studentId}</strong> &bull; {student.grade} &bull; {student.school}
            </p>
          </div>
        </div>

        {/* Primary Digital QR Pass Button */}
        <button
          onClick={() => onOpenStudentQR(student.studentId)}
          id="btn-show-my-qr-banner"
          className="flex items-center gap-3 rounded-2xl bg-white hover:bg-blue-50 text-slate-900 px-6 py-3.5 font-bold shadow-lg transition active:scale-95 group shrink-0"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center group-hover:scale-105 transition">
            <QrCode className="w-6 h-6" />
          </div>
          <div className="text-left">
            <span className="block text-xs font-black uppercase text-blue-600">Digital ID Pass</span>
            <span className="text-sm font-extrabold">Show Full Screen QR</span>
          </div>
        </button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Attendance Summary */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Attendance Rate
          </span>
          <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            96%
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">{attendance.length} sessions verified via QR</p>
        </div>

        {/* Fee Standing */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Fee Standing
          </span>
          <h3 className={`text-2xl font-black mt-1 ${pendingFees.length > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
            {pendingFees.length > 0 ? `Rs. ${pendingFees[0].balance.toLocaleString()} Due` : 'Fees Cleared'}
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">{receipts.length} verified payment receipts</p>
        </div>

        {/* Academic Rank / Average */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Academic Performance
          </span>
          <h3 className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
            Grade A (88%)
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">Term 2 Exam Rank: 3rd in Batch</p>
        </div>
      </div>

      {/* Main Sections: Exam Marks & Receipts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Exam Reports */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-500" />
            Official Examination Marks & Teacher Remarks
          </h3>

          <div className="space-y-2.5">
            {exams.length === 0 ? (
              <p className="text-xs text-slate-400 py-4">No exam records published yet.</p>
            ) : (
              exams.map(ex => (
                <div
                  key={ex.resultId}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white">{ex.examName}</h4>
                      <p className="text-[11px] text-slate-500">{ex.date}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-black text-blue-600 dark:text-blue-400">
                        {ex.marks} / {ex.totalMarks} ({ex.percentage}%)
                      </span>
                      <span className="block text-[10px] font-bold text-emerald-600">
                        Grade {ex.gradeLetter}
                      </span>
                    </div>
                  </div>

                  <p className="mt-2 text-[11px] text-slate-600 dark:text-slate-300 italic bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                    "{ex.teacherRemarks}"
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* My Receipts Archive */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            Payment Receipts Archive
          </h3>

          <div className="space-y-2.5">
            {receipts.length === 0 ? (
              <p className="text-xs text-slate-400 py-4">No receipts available.</p>
            ) : (
              receipts.map(rec => (
                <div
                  key={rec.receiptId}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <strong className="text-slate-900 dark:text-white">{rec.receiptNumber}</strong>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                        PAID
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {rec.billingMonth} &bull; Paid Rs. {rec.paid.toLocaleString()} via {rec.paymentMethod}
                    </p>
                  </div>

                  <button
                    onClick={() => onOpenReceipt(rec)}
                    className="flex items-center gap-1 rounded-xl bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 px-3 py-1.5 font-bold transition"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Receipt</span>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
