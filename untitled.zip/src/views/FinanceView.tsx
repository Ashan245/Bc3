import React, { useState } from 'react';
import {
  CreditCard,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Receipt as ReceiptIcon,
  Search,
  Filter,
  Download,
  Calendar,
  CheckCircle2,
  Send,
  PlusCircle,
} from 'lucide-react';
import { Fee, Receipt } from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';

interface FinanceViewProps {
  onOpenPayment: (fee: Fee) => void;
  onOpenReceipt: (receipt: Receipt) => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  onOpenPayment,
  onOpenReceipt,
}) => {
  const { role, isSuperAdmin, isAdmin, isStaff } = useAuth();
  const { settings } = useSettings();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [invoicesGenerated, setInvoicesGenerated] = useState<number | null>(null);

  const fees = storageService.getFees();
  const receipts = storageService.getReceipts();

  // Metrics
  const totalInvoiced = fees.reduce((sum, f) => sum + f.amount, 0);
  const totalCollected = fees.reduce((sum, f) => sum + f.paidAmount, 0);
  const totalOutstanding = fees.reduce((sum, f) => sum + f.balance, 0);
  const collectionRate = totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0;

  const filteredFees = fees.filter(fee => {
    const matchStatus = selectedStatus === 'ALL' || fee.status === selectedStatus;
    const matchMonth = selectedMonth === 'ALL' || fee.billingMonth === selectedMonth;
    const matchQuery =
      fee.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fee.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fee.grade.toLowerCase().includes(searchQuery.toLowerCase());
    return matchStatus && matchMonth && matchQuery;
  });

  const handleGenerateInvoices = () => {
    const activeStudents = storageService.getStudents(false).filter(s => s.status === 'ACTIVE');
    const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
    let createdCount = 0;

    activeStudents.forEach(student => {
      const existing = fees.find(f => f.studentId === student.studentId && f.billingMonth === currentMonth);
      if (!existing) {
        const studentClass = storageService.getClasses().find(c => c.classId === student.classId);
        const amount = studentClass?.feeAmount || 3500;

        storageService.saveFee({
          feeId: `FEE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          studentId: student.studentId,
          studentName: student.fullName,
          classId: student.classId,
          className: student.className,
          grade: student.grade,
          feeType: 'MONTHLY',
          amount,
          paidAmount: 0,
          discount: 0,
          balance: amount,
          billingMonth: currentMonth,
          dueDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
          status: 'UNPAID',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        createdCount++;
      }
    });

    setInvoicesGenerated(createdCount);
    setTimeout(() => setInvoicesGenerated(null), 3500);
  };

  const handleExportCSV = () => {
    const headers = ['FeeID', 'StudentID', 'StudentName', 'Grade', 'BillingMonth', 'Amount', 'Paid', 'Discount', 'Balance', 'Status', 'DueDate'];
    const rows = filteredFees.map(f => [
      f.feeId,
      f.studentId,
      `"${f.studentName}"`,
      f.grade,
      `"${f.billingMonth}"`,
      f.amount,
      f.paidAmount,
      f.discount,
      f.balance,
      f.status,
      f.dueDate,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Fee_Ledger_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Finance & Student Fee Management
          </h2>
          <p className="text-xs text-slate-500">
            Tuition fee ledger, instant receipts, bank slip tracking & WhatsApp billing
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>

          {(isSuperAdmin || isAdmin || isStaff) && (
            <button
              onClick={handleGenerateInvoices}
              id="btn-generate-monthly-invoices"
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Generate Monthly Invoices</span>
            </button>
          )}
        </div>
      </div>

      {invoicesGenerated !== null && (
        <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Batch invoice generation complete! {invoicesGenerated} new invoices created.</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Total Invoiced
          </span>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            Rs. {totalInvoiced.toLocaleString()}
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">{fees.length} total billing records</p>
        </div>

        <div className="rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Total Collected
          </span>
          <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            Rs. {totalCollected.toLocaleString()}
          </h3>
          <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">{collectionRate}% collection rate</p>
        </div>

        <div className="rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Outstanding Arrears
          </span>
          <h3 className="text-2xl font-black text-red-600 dark:text-red-400 mt-1">
            Rs. {totalOutstanding.toLocaleString()}
          </h3>
          <p className="text-[11px] text-red-600 font-semibold mt-0.5">Unpaid or partially settled</p>
        </div>

        <div className="rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Receipts Issued
          </span>
          <h3 className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
            {receipts.length}
          </h3>
          <p className="text-[11px] text-blue-600 font-semibold mt-0.5">Official serialized receipts</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by student name, ID, or grade..."
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="PAID">Paid</option>
            <option value="PARTIAL">Partial</option>
            <option value="UNPAID">Unpaid</option>
            <option value="OVERDUE">Overdue</option>
          </select>
        </div>
      </div>

      {/* Fees Ledger Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Student</th>
                <th className="px-4 py-3.5">Billing Month</th>
                <th className="px-4 py-3.5">Total Amount</th>
                <th className="px-4 py-3.5">Paid / Discount</th>
                <th className="px-4 py-3.5">Balance</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredFees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    No fee records found.
                  </td>
                </tr>
              ) : (
                filteredFees.map(fee => {
                  const studentReceipts = receipts.filter(r => r.studentId === fee.studentId);
                  const latestReceipt = studentReceipts[studentReceipts.length - 1];

                  return (
                    <tr key={fee.feeId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3.5">
                        <p className="font-bold text-slate-900 dark:text-white">
                          {fee.studentName}
                        </p>
                        <p className="text-[11px] text-blue-600 font-semibold">{fee.studentId} &bull; {fee.grade}</p>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{fee.billingMonth}</span>
                        <p className="text-[10px] text-slate-400">Due: {fee.dueDate}</p>
                      </td>

                      <td className="px-4 py-3.5 font-bold text-slate-900 dark:text-white">
                        Rs. {fee.amount.toLocaleString()}
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="text-emerald-600 font-bold">Rs. {fee.paidAmount.toLocaleString()}</span>
                        {fee.discount > 0 && (
                          <span className="text-[10px] text-slate-400 block">
                            (Discount: Rs. {fee.discount})
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 font-black text-sm">
                        <span className={fee.balance > 0 ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}>
                          Rs. {fee.balance.toLocaleString()}
                        </span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          fee.status === 'PAID'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : fee.status === 'PARTIAL'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                        }`}>
                          {fee.status}
                        </span>
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {fee.balance > 0 && (isSuperAdmin || isAdmin || isStaff) && (
                            <button
                              onClick={() => onOpenPayment(fee)}
                              className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 text-xs font-bold transition shadow-xs"
                            >
                              Collect Fee
                            </button>
                          )}

                          {latestReceipt && (
                            <button
                              onClick={() => onOpenReceipt(latestReceipt)}
                              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition"
                              title="View Official Receipt"
                            >
                              <ReceiptIcon className="w-4 h-4 text-purple-600" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
