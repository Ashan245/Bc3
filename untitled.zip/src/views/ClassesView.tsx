import React, { useState } from 'react';
import {
  BookOpen,
  Calendar,
  Clock,
  Users,
  Plus,
  MapPin,
  DollarSign,
  ChevronRight,
  QrCode,
  CheckCircle2,
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';
import { AcademyClass, ClassSession } from '../types';

interface ClassesViewProps {
  onOpenQRScanner: () => void;
}

export const ClassesView: React.FC<ClassesViewProps> = ({ onOpenQRScanner }) => {
  const { role, isSuperAdmin, isAdmin, isTeacher } = useAuth();
  const [classes, setClasses] = useState<AcademyClass[]>(storageService.getClasses());
  const [sessions, setSessions] = useState<ClassSession[]>(storageService.getClassSessions());
  const [selectedClass, setSelectedClass] = useState<AcademyClass | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Academic Courses, Classes & Timetable
          </h2>
          <p className="text-xs text-slate-500">
            Weekly schedules, syllabus streams, room assignments & enrolled cohorts
          </p>
        </div>
      </div>

      {/* Class Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {classes.map(cls => {
          const enrolledStudents = storageService.getStudentsByClass(cls.classId);
          return (
            <div
              key={cls.classId}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-blue-400 transition"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold text-[10px]">
                    {cls.grade}
                  </span>
                  <span className="text-xs font-black text-slate-900 dark:text-white">
                    Rs. {cls.feeAmount.toLocaleString()} / mo
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-2">
                  {cls.name}
                </h3>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                  {cls.description}
                </p>

                <div className="mt-4 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-blue-600" />
                    <span>{cls.day}s &bull; {cls.startTime} - {cls.endTime}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{cls.room}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3.5 h-3.5 text-purple-600" />
                    <span>
                      {enrolledStudents.length} / {cls.maxStudents} Students Enrolled
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-semibold">
                  Teacher: {cls.teacherName}
                </span>

                <button
                  onClick={onOpenQRScanner}
                  className="flex items-center gap-1 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 text-xs font-bold transition shadow-xs"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Scan</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
