import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  UserPlus,
  QrCode,
  Edit2,
  Trash2,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Phone,
  Mail,
  School,
  Download,
  X,
  FileText,
  Calendar,
  CreditCard,
  GraduationCap,
} from 'lucide-react';
import { Student, QRCodeRecord, StudentStatus } from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';

interface StudentsViewProps {
  onOpenStudentQR: (studentId: string) => void;
  onOpenNewStudent: () => void;
  editingStudent: Student | null;
  setEditingStudent: (student: Student | null) => void;
  onViewStudentProfile?: (studentId: string) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  onOpenStudentQR,
  onOpenNewStudent,
  editingStudent,
  setEditingStudent,
  onViewStudentProfile,
}) => {
  const { role, isSuperAdmin, isAdmin, isStaff } = useAuth();
  const { settings } = useSettings();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState<'ALL' | StudentStatus>('ACTIVE');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [viewTab, setViewTab] = useState<'DETAILS' | 'ATTENDANCE' | 'FEES' | 'EXAMS'>('DETAILS');

  // Archive modal state
  const [archiveTargetStudent, setArchiveTargetStudent] = useState<Student | null>(null);
  const [archiveReason, setArchiveReason] = useState('');

  // Refresh trigger
  const [refreshKey, setRefreshKey] = useState(0);

  const students = storageService.getStudents(true);
  const classes = storageService.getClasses();

  const filteredStudents = students.filter(s => {
    const matchQuery =
      s.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentPhone.includes(searchQuery) ||
      s.parentPhone.includes(searchQuery) ||
      s.school.toLowerCase().includes(searchQuery.toLowerCase());
    const matchGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
    const matchStatus = selectedStatus === 'ALL' || s.status === selectedStatus;
    return matchQuery && matchGrade && matchStatus;
  });

  const handleArchiveConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!archiveTargetStudent || !archiveReason.trim()) return;

    storageService.archiveStudent(archiveTargetStudent.studentId, archiveReason, role);
    setArchiveTargetStudent(null);
    setArchiveReason('');
    setSelectedStudent(null);
    setRefreshKey(k => k + 1);
  };

  const handleExportCSV = () => {
    const headers = ['StudentID', 'FullName', 'Grade', 'Class', 'School', 'ParentName', 'ParentPhone', 'Status'];
    const rows = filteredStudents.map(s => [
      s.studentId,
      `"${s.fullName}"`,
      s.grade,
      `"${s.className}"`,
      `"${s.school}"`,
      `"${s.parentName}"`,
      s.parentPhone,
      s.status,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Students_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Student Information System (SIS)
          </h2>
          <p className="text-xs text-slate-500">
            Manage registrations, digital QR identities, class assignments & profiles
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>

          {(isSuperAdmin || isAdmin || isStaff) && (
            <button
              onClick={onOpenNewStudent}
              id="btn-register-student-top"
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-xs font-bold shadow-xs transition active:scale-95"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New Student</span>
            </button>
          )}
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by student name, STU ID, school, phone..."
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={selectedGrade}
            onChange={e => setSelectedGrade(e.target.value)}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-800 dark:text-white"
          >
            <option value="ALL">All Grades</option>
            <option value="Grade 6">Grade 6</option>
            <option value="Grade 7">Grade 7</option>
            <option value="Grade 8">Grade 8</option>
            <option value="Grade 9">Grade 9</option>
            <option value="Grade 10">Grade 10</option>
            <option value="Grade 11">Grade 11</option>
            <option value="Grade 12">Grade 12</option>
          </select>

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value as any)}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-800 dark:text-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
            <option value="ARCHIVED">Archived (Recycle Bin)</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </div>
      </div>

      {/* Students Data Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Student</th>
                <th className="px-4 py-3.5">Grade & Class</th>
                <th className="px-4 py-3.5">School</th>
                <th className="px-4 py-3.5">Contact / WhatsApp</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400">
                    No students match your criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map(student => {
                  const qr = storageService.getActiveQRForStudent(student.studentId);
                  return (
                    <tr
                      key={student.studentId}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                            alt={student.fullName}
                            className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div>
                            <button
                              onClick={() => setSelectedStudent(student)}
                              className="font-bold text-slate-900 dark:text-white hover:text-blue-600 text-left cursor-pointer"
                            >
                              {student.fullName}
                            </button>
                            <p className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold">
                              {student.studentId}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {student.grade}
                        </span>
                        <p className="text-[11px] text-slate-500 truncate max-w-[160px]">
                          {student.className}
                        </p>
                      </td>

                      <td className="px-4 py-3.5 truncate max-w-[180px]">
                        {student.school}
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-emerald-600" />
                          <span>{student.parentPhone}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          {student.parentName} ({student.parentRelationship})
                        </p>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          student.status === 'ACTIVE'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : student.status === 'ARCHIVED'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}>
                          {student.status}
                        </span>
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {/* Digital QR Card View */}
                          <button
                            onClick={() => onOpenStudentQR(student.studentId)}
                            className="p-1.5 rounded-lg bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 hover:bg-blue-100 transition"
                            title="Show Full Screen QR ID Card"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>

                          {/* Profile details */}
                          <button
                            onClick={() => {
                              if (onViewStudentProfile) {
                                onViewStudentProfile(student.studentId);
                              } else {
                                setSelectedStudent(student);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition"
                            title="View Full Profile"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          {/* Edit */}
                          {(isSuperAdmin || isAdmin) && (
                            <button
                              onClick={() => setEditingStudent(student)}
                              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition"
                              title="Edit Student"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}

                          {/* Archive */}
                          {(isSuperAdmin || isAdmin) && student.status !== 'ARCHIVED' && (
                            <button
                              onClick={() => setArchiveTargetStudent(student)}
                              className="p-1.5 rounded-lg bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-300 hover:bg-red-100 transition"
                              title="Move to Recycle Bin (Archive)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Details Drawer / Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-3 sm:p-4 backdrop-blur-xs">
          <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-3">
                <img
                  src={selectedStudent.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120'}
                  alt={selectedStudent.fullName}
                  className="w-12 h-12 rounded-2xl object-cover border border-slate-200 dark:border-slate-700"
                />
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {selectedStudent.fullName}
                  </h3>
                  <p className="text-xs text-blue-600 font-semibold">
                    {selectedStudent.studentId} &bull; {selectedStudent.grade} ({selectedStudent.className})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 gap-4 text-xs font-bold text-slate-500">
              <button
                onClick={() => setViewTab('DETAILS')}
                className={`py-3 border-b-2 transition ${
                  viewTab === 'DETAILS' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-800'
                }`}
              >
                Profile & QR
              </button>
              <button
                onClick={() => setViewTab('ATTENDANCE')}
                className={`py-3 border-b-2 transition ${
                  viewTab === 'ATTENDANCE' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-800'
                }`}
              >
                Attendance Records
              </button>
              <button
                onClick={() => setViewTab('FEES')}
                className={`py-3 border-b-2 transition ${
                  viewTab === 'FEES' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-800'
                }`}
              >
                Fee Ledger & Receipts
              </button>
              <button
                onClick={() => setViewTab('EXAMS')}
                className={`py-3 border-b-2 transition ${
                  viewTab === 'EXAMS' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-800'
                }`}
              >
                Exam Marks
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 flex-1 overflow-y-auto space-y-4 text-xs">
              {viewTab === 'DETAILS' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Date of Birth</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.dob || 'N/A'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">School</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.school}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Parent / Guardian</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.parentName} ({selectedStudent.parentRelationship})</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Parent WhatsApp</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.parentPhone}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Emergency Contact</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.emergencyContact || 'N/A'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Registration Date</span>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedStudent.registrationDate}</p>
                    </div>
                  </div>

                  {/* QR Status Box */}
                  <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-blue-900 dark:text-blue-200 uppercase">
                        Digital Attendance QR Status
                      </span>
                      <p className="text-xs font-bold text-slate-900 dark:text-white mt-0.5">
                        Active QR Token Assigned
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Scan count: {storageService.getActiveQRForStudent(selectedStudent.studentId)?.scanCount || 0} scans
                      </p>
                    </div>

                    <button
                      onClick={() => onOpenStudentQR(selectedStudent.studentId)}
                      className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-bold shadow-xs transition"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>View & Print ID Card</span>
                    </button>
                  </div>
                </div>
              )}

              {viewTab === 'ATTENDANCE' && (
                <div className="space-y-2">
                  {storageService.getAttendanceForStudent(selectedStudent.studentId).length === 0 ? (
                    <div className="p-6 text-center text-slate-400">No attendance records logged yet.</div>
                  ) : (
                    storageService.getAttendanceForStudent(selectedStudent.studentId).map(att => (
                      <div
                        key={att.attendanceId}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex justify-between items-center"
                      >
                        <div>
                          <p className="font-bold text-slate-900 dark:text-white">{att.className}</p>
                          <p className="text-[11px] text-slate-500">
                            {att.date} &bull; Verified by {att.markedByName} ({att.attendanceMethod})
                          </p>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          att.status === 'PRESENT' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {att.status}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {viewTab === 'FEES' && (
                <div className="space-y-2">
                  {storageService.getFeesForStudent(selectedStudent.studentId).map(fee => (
                    <div
                      key={fee.feeId}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex justify-between items-center"
                    >
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{fee.billingMonth}</p>
                        <p className="text-[11px] text-slate-500">
                          Fee: Rs. {fee.amount.toLocaleString()} &bull; Paid: Rs. {fee.paidAmount.toLocaleString()} &bull; Balance: Rs. {fee.balance.toLocaleString()}
                        </p>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        fee.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {fee.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {viewTab === 'EXAMS' && (
                <div className="space-y-2">
                  {storageService.getExamResults(selectedStudent.studentId).map(exam => (
                    <div
                      key={exam.resultId}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800"
                    >
                      <div className="flex justify-between items-center">
                        <p className="font-bold text-slate-900 dark:text-white">{exam.examName}</p>
                        <span className="text-sm font-black text-blue-600">{exam.percentage}% (Grade {exam.gradeLetter})</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 italic">
                        "{exam.teacherRemarks}"
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-between">
              {(isSuperAdmin || isAdmin) && selectedStudent.status !== 'ARCHIVED' && (
                <button
                  onClick={() => {
                    setArchiveTargetStudent(selectedStudent);
                  }}
                  className="text-xs font-semibold text-red-600 hover:underline flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Archive Student</span>
                </button>
              )}
              <button
                onClick={() => setSelectedStudent(null)}
                className="ml-auto rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-800 dark:text-slate-200 px-4 py-1.5 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Archive Reason Confirmation Modal (Section 13) */}
      {archiveTargetStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              Archive Student (Move to Recycle Bin)
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Archiving <strong>{archiveTargetStudent.fullName}</strong> ({archiveTargetStudent.studentId}) will automatically revoke their attendance QR token.
            </p>

            <form onSubmit={handleArchiveConfirm} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Reason for Archival *
                </label>
                <textarea
                  value={archiveReason}
                  onChange={e => setArchiveReason(e.target.value)}
                  placeholder="e.g. Transferred to another branch, completed O/L exams, left academy..."
                  required
                  rows={2}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setArchiveTargetStudent(null)}
                  className="rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-red-600 hover:bg-red-700 text-white px-4 py-1.5 text-xs font-bold transition"
                >
                  Confirm Archival
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
