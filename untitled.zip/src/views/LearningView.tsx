import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  BookOpen,
  FileText,
  Video,
  Music,
  Download,
  Plus,
  Search,
  CheckCircle2,
  Calendar,
  Sparkles,
  Play,
  Clock,
  Award,
  AlertCircle,
  HelpCircle,
  Upload,
  Send,
  Check,
  X,
} from 'lucide-react';
import {
  LMSMaterial,
  Lesson,
  Quiz,
  QuizAttempt,
  Homework,
  HomeworkSubmission,
  StudentLessonProgress,
} from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';

export const LearningView: React.FC = () => {
  const { role, isSuperAdmin, isAdmin, isTeacher, currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'LESSONS' | 'QUIZZES' | 'HOMEWORK' | 'MATERIALS'>('LESSONS');

  // Active student for LMS progress (logged in or default STU-000001)
  const studentId = currentUser?.studentId || 'STU-000001';
  const studentName = currentUser?.name || 'Kasun Lakshan Perera';

  // Data states
  const [materials, setMaterials] = useState<LMSMaterial[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [homeworkList, setHomeworkList] = useState<Homework[]>([]);
  const [submissions, setSubmissions] = useState<HomeworkSubmission[]>([]);
  const [progressList, setProgressList] = useState<StudentLessonProgress[]>([]);
  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>([]);

  // Filters
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Active Viewers
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [lessonWatchPercent, setLessonWatchPercent] = useState<number>(0);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);

  // Interactive Quiz Taking State
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [quizUserAnswers, setQuizUserAnswers] = useState<Record<string, string>>({});
  const [quizCompletedAttempt, setQuizCompletedAttempt] = useState<QuizAttempt | null>(null);

  // Homework submission modal & grading
  const [selectedHomeworkForSubmit, setSelectedHomeworkForSubmit] = useState<Homework | null>(null);
  const [homeworkContent, setHomeworkContent] = useState('');
  const [gradingSubmissionId, setGradingSubmissionId] = useState<string | null>(null);
  const [gradingMarks, setGradingMarks] = useState<number>(0);
  const [gradingFeedback, setGradingFeedback] = useState<string>('');

  // Add Material Modal
  const [showAddMaterialModal, setShowAddMaterialModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newType, setNewType] = useState<'PDF' | 'VIDEO' | 'AUDIO' | 'ASSIGNMENT'>('PDF');
  const [newUrl, setNewUrl] = useState('');
  const [newGrade, setNewGrade] = useState('Grade 8');

  // Add Lesson Modal
  const [showAddLessonModal, setShowAddLessonModal] = useState(false);
  const [newLessonTitle, setNewLessonTitle] = useState('');
  const [newLessonGrade, setNewLessonGrade] = useState('Grade 8');
  const [newLessonDesc, setNewLessonDesc] = useState('');
  const [newLessonVideo, setNewLessonVideo] = useState('https://www.w3schools.com/html/mov_bbb.mp4');
  const [newLessonDuration, setNewLessonDuration] = useState(30);
  const [newLessonSkill, setNewLessonSkill] = useState<'Grammar' | 'Vocabulary' | 'Writing' | 'Speaking'>('Grammar');

  // Load all initial data
  const loadData = () => {
    setMaterials(storageService.getLMSMaterials());
    setLessons(storageService.getLessons());
    setQuizzes(storageService.getQuizzes());
    setHomeworkList(storageService.getHomework());
    setSubmissions(storageService.getHomeworkSubmissions());
    setProgressList(storageService.getStudentLessonProgress(studentId));
    setQuizAttempts(storageService.getQuizAttempts(studentId));
  };

  useEffect(() => {
    loadData();
  }, [studentId]);

  // Video progress updater
  const handleUpdateProgress = (lessonId: string, percentage: number) => {
    storageService.updateLessonProgress(studentId, lessonId, percentage, Math.round((percentage / 100) * 1800));
    loadData();
    setLessonWatchPercent(percentage);
  };

  // Submit Quiz Attempt
  const handleSubmitQuiz = (quiz: Quiz) => {
    let score = 0;
    const totalMarks = quiz.questions.reduce((sum, q) => sum + q.marks, 0);

    quiz.questions.forEach(q => {
      const ans = quizUserAnswers[q.questionId]?.trim().toLowerCase();
      const correct = q.correctAnswer?.trim().toLowerCase();
      if (ans && ans === correct) {
        score += q.marks;
      }
    });

    const percentage = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 100;
    const isPassed = percentage >= quiz.passMarkPercentage;

    const attempt = storageService.submitQuizAttempt({
      quizId: quiz.quizId,
      studentId,
      studentName,
      startedAt: new Date(Date.now() - 600000).toISOString(),
      completedAt: new Date().toISOString(),
      score,
      totalMarks,
      percentage,
      isPassed,
      answers: quizUserAnswers,
    });

    setQuizCompletedAttempt(attempt);
    loadData();
  };

  // Submit Homework by student
  const handleStudentHomeworkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHomeworkForSubmit || !homeworkContent.trim()) return;

    storageService.submitHomework({
      homeworkId: selectedHomeworkForSubmit.homeworkId,
      studentId,
      studentName,
      content: homeworkContent.trim(),
      status: 'SUBMITTED',
    });

    setSelectedHomeworkForSubmit(null);
    setHomeworkContent('');
    loadData();
  };

  // Grade Homework by teacher
  const handleTeacherGrade = (submissionId: string) => {
    storageService.gradeHomework(submissionId, gradingMarks, gradingFeedback, currentUser?.name || 'Teacher Evaluator');
    setGradingSubmissionId(null);
    setGradingMarks(0);
    setGradingFeedback('');
    loadData();
  };

  // Create new Material
  const handleCreateMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created: LMSMaterial = {
      materialId: `LMS-${Date.now()}`,
      title: newTitle.trim(),
      description: newDescription.trim(),
      type: newType,
      fileUrl: newUrl.trim() || 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      classId: 'CLS-G08-SAT',
      className: `${newGrade} English Mastery`,
      grade: newGrade,
      uploadedBy: currentUser?.name || 'Faculty Staff',
      uploadedAt: new Date().toISOString().split('T')[0],
      downloadsCount: 0,
    };

    const updated = storageService.saveLMSMaterial(created);
    setMaterials(updated);
    setShowAddMaterialModal(false);
    setNewTitle('');
    setNewDescription('');
    setNewUrl('');
  };

  // Create new Lesson
  const handleCreateLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLessonTitle.trim()) return;

    const newLesson: Lesson = {
      lessonId: `LES-${Date.now()}`,
      classId: 'CLS-G08-SAT',
      grade: newLessonGrade,
      title: newLessonTitle.trim(),
      description: newLessonDesc.trim(),
      videoUrl: newLessonVideo.trim() || 'https://www.w3schools.com/html/mov_bbb.mp4',
      durationMinutes: Number(newLessonDuration) || 30,
      order: lessons.length + 1,
      status: 'PUBLISHED',
      skillFocus: newLessonSkill,
      publishedAt: new Date().toISOString(),
    };

    storageService.saveLesson(newLesson);
    loadData();
    setShowAddLessonModal(false);
    setNewLessonTitle('');
    setNewLessonDesc('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Curriculum, Video Lessons & Digital LMS
          </h2>
          <p className="text-xs text-slate-500">
            Recorded video masterclasses, interactive grammar quizzes, homework submission & course handouts
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(isSuperAdmin || isAdmin || isTeacher) && (
            <>
              <button
                onClick={() => setShowAddLessonModal(true)}
                id="btn-upload-video-lesson"
                className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
              >
                <Video className="w-4 h-4" />
                <span>+ New Video Lesson</span>
              </button>

              <button
                onClick={() => setShowAddMaterialModal(true)}
                id="btn-upload-lms-material"
                className="flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
              >
                <Upload className="w-4 h-4" />
                <span>+ Upload Handout</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 overflow-x-auto">
        <button
          onClick={() => setActiveTab('LESSONS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'LESSONS'
              ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Video Lessons ({lessons.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('QUIZZES')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'QUIZZES'
              ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Interactive Quizzes ({quizzes.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('HOMEWORK')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'HOMEWORK'
              ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Homework & Tasks ({homeworkList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('MATERIALS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'MATERIALS'
              ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Study Handouts & PDFs ({materials.length})</span>
        </button>
      </div>

      {/* TAB 1: VIDEO LESSONS & PROGRESS TRACKER */}
      {activeTab === 'LESSONS' && (
        <div className="space-y-4">
          {/* Active Lesson Player Banner */}
          {activeLesson && (
            <div className="p-6 rounded-3xl bg-slate-900 text-white shadow-xl space-y-4 border border-slate-800 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-500/30 text-blue-300 font-bold text-xs">
                    {activeLesson.grade} &bull; {activeLesson.skillFocus}
                  </span>
                  <span className="text-xs text-slate-400">
                    Duration: {activeLesson.durationMinutes} mins
                  </span>
                </div>
                <button
                  onClick={() => setActiveLesson(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <h3 className="text-lg font-bold">{activeLesson.title}</h3>
              <p className="text-xs text-slate-300">{activeLesson.description}</p>

              {/* Interactive Video Player Canvas */}
              <div className="relative aspect-video rounded-2xl bg-black overflow-hidden flex flex-col items-center justify-center border border-slate-800 shadow-inner">
                <video
                  src={activeLesson.videoUrl}
                  controls
                  className="w-full h-full object-contain"
                  onPlay={() => setIsPlayingVideo(true)}
                  onPause={() => setIsPlayingVideo(false)}
                />
              </div>

              {/* Watch Progress Slider & Actions */}
              <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">Watch Progress:</span>
                  <span className="font-black text-blue-400">{lessonWatchPercent}% Completed</span>
                </div>

                <div className="w-full bg-slate-700 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-blue-500 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${lessonWatchPercent}%` }}
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdateProgress(activeLesson.lessonId, 50)}
                      className="px-3 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200"
                    >
                      Set 50%
                    </button>
                    <button
                      onClick={() => handleUpdateProgress(activeLesson.lessonId, 100)}
                      className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Mark 100% Watched</span>
                    </button>
                  </div>

                  <span className="text-[11px] text-slate-400">
                    {lessonWatchPercent >= 90 ? '✅ Lesson marked as fully completed!' : 'Progress saved automatically to your profile.'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Lessons Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {lessons.map(lesson => {
              const prog = progressList.find(p => p.lessonId === lesson.lessonId);
              const watchPercent = prog?.watchPercentage || 0;
              const isDone = prog?.isCompleted || watchPercent >= 90;

              return (
                <div
                  key={lesson.lessonId}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-blue-400 transition"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                        {lesson.grade} &bull; {lesson.skillFocus}
                      </span>
                      {isDone ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Completed</span>
                        </span>
                      ) : (
                        <span className="text-[11px] font-bold text-slate-400">
                          {watchPercent > 0 ? `${watchPercent}% watched` : 'Not started'}
                        </span>
                      )}
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-2.5 line-clamp-2">
                      {lesson.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {lesson.description}
                    </p>

                    <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{lesson.durationMinutes} mins</span>
                      </span>
                    </div>

                    {/* Mini Progress Bar */}
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 mt-3 overflow-hidden">
                      <div
                        className={`h-1.5 rounded-full ${isDone ? 'bg-emerald-500' : 'bg-blue-500'}`}
                        style={{ width: `${watchPercent}%` }}
                      />
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Lesson #{lesson.order || 1}
                    </span>

                    <button
                      onClick={() => {
                        setActiveLesson(lesson);
                        setLessonWatchPercent(watchPercent);
                      }}
                      className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 text-xs font-bold transition shadow-xs"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>{watchPercent > 0 ? 'Resume' : 'Watch'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: INTERACTIVE QUIZZES */}
      {activeTab === 'QUIZZES' && (
        <div className="space-y-4">
          {/* Active Quiz Taking Modal */}
          {activeQuiz && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
              <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
                      Interactive Assessment
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {activeQuiz.title}
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      setActiveQuiz(null);
                      setQuizCompletedAttempt(null);
                    }}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
                  {/* If completed, show result overview */}
                  {quizCompletedAttempt ? (
                    <div className="p-5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center space-y-2">
                      <Award className={`w-12 h-12 mx-auto ${quizCompletedAttempt.isPassed ? 'text-emerald-500' : 'text-amber-500'}`} />
                      <h4 className="text-base font-black text-slate-900 dark:text-white">
                        {quizCompletedAttempt.isPassed ? 'Congratulations! Quiz Passed' : 'Quiz Completed - Review Answers'}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        Score: <strong>{quizCompletedAttempt.score} / {quizCompletedAttempt.totalMarks}</strong> ({quizCompletedAttempt.percentage}%)
                        &bull; Pass Mark: {activeQuiz.passMarkPercentage}%
                      </p>
                    </div>
                  ) : null}

                  {/* Questions List */}
                  {activeQuiz.questions.map((q, idx) => {
                    const selected = quizUserAnswers[q.questionId] || '';
                    const isSubmitted = !!quizCompletedAttempt;
                    const isCorrect = isSubmitted && selected.trim().toLowerCase() === q.correctAnswer?.trim().toLowerCase();

                    return (
                      <div
                        key={q.questionId}
                        className={`p-4 rounded-2xl border ${
                          isSubmitted
                            ? isCorrect
                              ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                              : 'bg-red-50/50 dark:bg-red-950/20 border-red-300 dark:border-red-800'
                            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                        } space-y-3`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-bold text-slate-900 dark:text-white">
                            {idx + 1}. {q.question}
                          </p>
                          <span className="text-[10px] font-bold text-slate-400 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md shrink-0">
                            {q.marks} pts
                          </span>
                        </div>

                        {/* Options */}
                        {q.options && q.options.length > 0 ? (
                          <div className="space-y-1.5">
                            {q.options.map((opt, oIdx) => (
                              <label
                                key={oIdx}
                                className={`flex items-center gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
                                  selected === opt
                                    ? 'bg-blue-50 dark:bg-blue-900/40 border-blue-500 font-bold text-blue-900 dark:text-blue-100'
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`question-${q.questionId}`}
                                  value={opt}
                                  checked={selected === opt}
                                  disabled={isSubmitted}
                                  onChange={() =>
                                    setQuizUserAnswers(prev => ({ ...prev, [q.questionId]: opt }))
                                  }
                                  className="accent-blue-600"
                                />
                                <span>{opt}</span>
                              </label>
                            ))}
                          </div>
                        ) : (
                          <div>
                            <input
                              type="text"
                              value={selected}
                              disabled={isSubmitted}
                              onChange={e =>
                                setQuizUserAnswers(prev => ({ ...prev, [q.questionId]: e.target.value }))
                              }
                              placeholder="Type your answer here..."
                              className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                            />
                          </div>
                        )}

                        {/* Explanation on submit */}
                        {isSubmitted && (
                          <div className="pt-2 text-[11px] text-slate-500 border-t border-slate-200 dark:border-slate-700">
                            <strong>Explanation:</strong> {q.explanation || `Correct Answer: ${q.correctAnswer}`}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {activeQuiz.questions.length} Total Questions
                  </span>

                  {!quizCompletedAttempt ? (
                    <button
                      onClick={() => handleSubmitQuiz(activeQuiz)}
                      className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 text-xs font-bold transition shadow-xs"
                    >
                      Submit Quiz & Check Score
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setActiveQuiz(null);
                        setQuizCompletedAttempt(null);
                      }}
                      className="rounded-xl bg-slate-800 hover:bg-slate-700 text-white px-5 py-2 text-xs font-bold transition shadow-xs"
                    >
                      Done & Close
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Quizzes List Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quizzes.map(quiz => {
              const attempts = quizAttempts.filter(a => a.quizId === quiz.quizId);
              const bestAttempt = attempts.sort((a, b) => b.score - a.score)[0];

              return (
                <div
                  key={quiz.quizId}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-blue-400 transition"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                        {quiz.grade} &bull; Quiz
                      </span>
                      <span className="text-[11px] font-bold text-slate-400">
                        Pass Mark: {quiz.passMarkPercentage}%
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-2.5">
                      {quiz.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {quiz.description}
                    </p>

                    <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                      <span>{quiz.questions.length} Questions</span>
                      <span>Time Limit: {quiz.timeLimitMinutes} mins</span>
                    </div>

                    {bestAttempt && (
                      <div className="mt-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-xs">
                        <span className="text-slate-500">Your Best Score:</span>
                        <span className={`font-black ${bestAttempt.isPassed ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {bestAttempt.score} / {bestAttempt.totalMarks} ({bestAttempt.percentage}%)
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      {attempts.length} attempts recorded
                    </span>

                    <button
                      onClick={() => {
                        setActiveQuiz(quiz);
                        setQuizUserAnswers({});
                        setQuizCompletedAttempt(null);
                      }}
                      className="flex items-center gap-1 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 text-xs font-bold transition shadow-xs"
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>{attempts.length > 0 ? 'Retake Quiz' : 'Take Quiz'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: HOMEWORK & SUBMISSIONS */}
      {activeTab === 'HOMEWORK' && (
        <div className="space-y-6">
          {/* Student Submit Homework Modal */}
          {selectedHomeworkForSubmit && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
              <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Submit Homework Solution
                  </h3>
                  <button
                    onClick={() => setSelectedHomeworkForSubmit(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                  <p className="font-bold text-slate-800 dark:text-slate-200">
                    {selectedHomeworkForSubmit.title}
                  </p>
                  <p className="text-slate-500 mt-1">{selectedHomeworkForSubmit.description}</p>
                </div>

                <form onSubmit={handleStudentHomeworkSubmit} className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      Your Written Submission / Essay Answer *
                    </label>
                    <textarea
                      rows={5}
                      required
                      value={homeworkContent}
                      onChange={e => setHomeworkContent(e.target.value)}
                      placeholder="Write or paste your completed assignment text..."
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setSelectedHomeworkForSubmit(null)}
                      className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 font-bold"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-xs flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Assignment</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Teacher Grading Modal */}
          {gradingSubmissionId && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
              <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Teacher Grading & Remarks
                  </h3>
                  <button
                    onClick={() => setGradingSubmissionId(null)}
                    className="p-1 rounded-lg text-slate-400"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      Marks Awarded
                    </label>
                    <input
                      type="number"
                      value={gradingMarks}
                      onChange={e => setGradingMarks(Number(e.target.value))}
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      Teacher Feedback & Grammar Corrections
                    </label>
                    <textarea
                      rows={3}
                      value={gradingFeedback}
                      onChange={e => setGradingFeedback(e.target.value)}
                      placeholder="Ex: Excellent vocabulary, please watch tense consistency in paragraph 2..."
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setGradingSubmissionId(null)}
                      className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleTeacherGrade(gradingSubmissionId)}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                    >
                      Save Marks & Send Feedback
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Homework Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {homeworkList.map(hw => {
              const mySub = submissions.find(s => s.homeworkId === hw.homeworkId && s.studentId === studentId);

              return (
                <div
                  key={hw.homeworkId}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300">
                      {hw.grade} &bull; Homework
                    </span>
                    <span className="text-xs text-red-600 font-semibold">
                      Due: {hw.dueDate}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      {hw.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{hw.description}</p>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Max Marks: {hw.maxMarks}</span>
                    <span className="text-slate-400">Assigned by: {hw.createdBy}</span>
                  </div>

                  {/* Submission status for student */}
                  {mySub ? (
                    <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Submitted</span>
                        </span>
                        {mySub.marksObtained !== undefined && (
                          <span className="font-black text-emerald-700 dark:text-emerald-400">
                            Marks: {mySub.marksObtained} / {hw.maxMarks}
                          </span>
                        )}
                      </div>
                      {mySub.feedback && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                          <strong>Teacher Feedback:</strong> {mySub.feedback}
                        </p>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={() => setSelectedHomeworkForSubmit(hw)}
                      className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Submit Solution</span>
                    </button>
                  )}

                  {/* Teacher Grading View */}
                  {(isSuperAdmin || isAdmin || isTeacher) && (
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                        Cohort Submissions ({submissions.filter(s => s.homeworkId === hw.homeworkId).length})
                      </span>
                      <div className="space-y-2">
                        {submissions
                          .filter(s => s.homeworkId === hw.homeworkId)
                          .map(sub => (
                            <div
                              key={sub.submissionId}
                              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 flex items-center justify-between text-xs"
                            >
                              <div>
                                <span className="font-bold text-slate-800 dark:text-slate-200">
                                  {sub.studentName}
                                </span>
                                <span className="block text-[10px] text-slate-400">
                                  {sub.marksObtained !== undefined
                                    ? `Graded: ${sub.marksObtained}/${hw.maxMarks}`
                                    : 'Awaiting Evaluation'}
                                </span>
                              </div>

                              <button
                                onClick={() => {
                                  setGradingSubmissionId(sub.submissionId);
                                  setGradingMarks(sub.marksObtained || 15);
                                  setGradingFeedback(sub.feedback || '');
                                }}
                                className="px-3 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-blue-600 hover:text-white text-slate-800 dark:text-slate-200 font-bold transition"
                              >
                                {sub.marksObtained !== undefined ? 'Edit Grade' : 'Grade'}
                              </button>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: MATERIALS & HANDOUTS */}
      {activeTab === 'MATERIALS' && (
        <div className="space-y-4">
          {/* Filter Toolbar */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search grammar rules, worksheets, vocabulary guides..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex gap-2">
              <select
                value={selectedGrade}
                onChange={e => setSelectedGrade(e.target.value)}
                className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-800 dark:text-white"
              >
                <option value="ALL">All Grades</option>
                <option value="Grade 6">Grade 6</option>
                <option value="Grade 7">Grade 7</option>
                <option value="Grade 8">Grade 8</option>
                <option value="Grade 9">Grade 9</option>
                <option value="Grade 10">Grade 10</option>
                <option value="Grade 11">Grade 11</option>
              </select>
            </div>
          </div>

          {/* Handouts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {materials
              .filter(m => (selectedGrade === 'ALL' || m.grade === selectedGrade) &&
                (m.title.toLowerCase().includes(searchQuery.toLowerCase()) || m.description.toLowerCase().includes(searchQuery.toLowerCase())))
              .map(m => (
                <div
                  key={m.materialId}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-blue-400 transition"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        m.type === 'PDF'
                          ? 'bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                          : m.type === 'AUDIO'
                          ? 'bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                          : 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                      }`}>
                        {m.type}
                      </span>
                      <span className="text-[11px] font-semibold text-slate-400">{m.grade}</span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-2.5">
                      {m.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {m.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Uploaded {m.uploadedAt}
                    </span>

                    <a
                      href={m.fileUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200 transition"
                    >
                      <Download className="w-3.5 h-3.5 text-blue-600" />
                      <span>Access File</span>
                    </a>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Upload Handout Modal */}
      {showAddMaterialModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Add New LMS Lesson Handout
            </h3>

            <form onSubmit={handleCreateMaterial} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Lesson Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="Ex: Grade 8 Passive Voice Rules"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Format / Material Type
                </label>
                <select
                  value={newType}
                  onChange={e => setNewType(e.target.value as any)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                >
                  <option value="PDF">PDF Handout / Worksheet</option>
                  <option value="AUDIO">Audio Pronunciation / Listening</option>
                  <option value="VIDEO">Video Recorded Lecture</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Target Grade
                </label>
                <select
                  value={newGrade}
                  onChange={e => setNewGrade(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                >
                  <option value="Grade 6">Grade 6</option>
                  <option value="Grade 7">Grade 7</option>
                  <option value="Grade 8">Grade 8</option>
                  <option value="Grade 9">Grade 9</option>
                  <option value="Grade 10">Grade 10</option>
                  <option value="Grade 11">Grade 11</option>
                  <option value="General">General Spoken English</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  File Resource URL
                </label>
                <input
                  type="text"
                  value={newUrl}
                  onChange={e => setNewUrl(e.target.value)}
                  placeholder="https://... or sample PDF link"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  placeholder="Brief synopsis of what this resource covers..."
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddMaterialModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  Upload Resource
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Lesson Modal */}
      {showAddLessonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Create New Video Lecture Lesson
            </h3>

            <form onSubmit={handleCreateLesson} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Lesson Title *
                </label>
                <input
                  type="text"
                  required
                  value={newLessonTitle}
                  onChange={e => setNewLessonTitle(e.target.value)}
                  placeholder="Ex: Direct vs Indirect Speech Masterclass"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Grade
                  </label>
                  <select
                    value={newLessonGrade}
                    onChange={e => setNewLessonGrade(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                  >
                    <option value="Grade 6">Grade 6</option>
                    <option value="Grade 7">Grade 7</option>
                    <option value="Grade 8">Grade 8</option>
                    <option value="Grade 9">Grade 9</option>
                    <option value="Grade 10">Grade 10</option>
                    <option value="Grade 11">Grade 11</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Skill Focus
                  </label>
                  <select
                    value={newLessonSkill}
                    onChange={e => setNewLessonSkill(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                  >
                    <option value="Grammar">Grammar</option>
                    <option value="Vocabulary">Vocabulary</option>
                    <option value="Writing">Writing</option>
                    <option value="Speaking">Speaking</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Video Source URL
                </label>
                <input
                  type="text"
                  value={newLessonVideo}
                  onChange={e => setNewLessonVideo(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Duration (Minutes)
                </label>
                <input
                  type="number"
                  value={newLessonDuration}
                  onChange={e => setNewLessonDuration(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={newLessonDesc}
                  onChange={e => setNewLessonDesc(e.target.value)}
                  placeholder="What will the student master in this lecture?"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddLessonModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  Publish Video Lesson
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
