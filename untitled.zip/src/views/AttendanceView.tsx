import React, { useState } from 'react';
import {
  CalendarCheck,
  QrCode,
  Search,
  Download,
  CheckCircle2,
  Clock,
  AlertCircle,
  RefreshCw,
  UserCheck,
  Filter,
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';
import { AttendanceRecord, ClassSession } from '../types';

interface AttendanceViewProps {
  onOpenQRScanner: () => void;
  onOpenManualAttendance: () => void;
  onOpenDailyRegister?: () => void;
  onViewStudentProfile?: (studentId: string) => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  onOpenQRScanner,
  onOpenManualAttendance,
  onOpenDailyRegister,
  onViewStudentProfile,
}) => {
  const { role, isSuperAdmin, isAdmin, isTeacher, isStaff } = useAuth();

  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [syncedCount, setSyncedCount] = useState<number | null>(null);

  const classes = storageService.getClasses();
  const sessions = storageService.getClassSessions();
  const attendanceLogs = storageService.getAttendance();
  const offlineQueue = storageService.getOfflineAttendanceQueue();

  const handleSyncOffline = () => {
    const count = storageService.syncOfflineAttendance();
    setSyncedCount(count);
    setTimeout(() => setSyncedCount(null), 3000);
  };

  const filteredLogs = attendanceLogs.filter(log => {
    const matchClass = selectedClassId === 'ALL' || log.classId === selectedClassId;
    const matchStatus = selectedStatus === 'ALL' || log.status === selectedStatus;
    const matchQuery =
      log.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.className.toLowerCase().includes(searchQuery.toLowerCase());
    return matchClass && matchStatus && matchQuery;
  });

  const handleExportCSV = () => {
    const headers = ['AttendanceID', 'StudentID', 'StudentName', 'Class', 'Date', 'Status', 'Method', 'MarkedBy', 'MarkedAt'];
    const rows = filteredLogs.map(l => [
      l.attendanceId,
      l.studentId,
      `"${l.studentName}"`,
      `"${l.className}"`,
      l.date,
      l.status,
      l.attendanceMethod,
      `"${l.markedByName}"`,
      l.markedAt,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Attendance_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Attendance Tracking & Verification
          </h2>
          <p className="text-xs text-slate-500">
            Real-time QR scanning, offline sync queue, and historical attendance logs
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {offlineQueue.length > 0 && (
            <button
              onClick={handleSyncOffline}
              id="btn-sync-offline-queue"
              className="flex items-center gap-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white px-3 py-2 text-xs font-bold transition shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Sync {offlineQueue.length} Offline Record(s)</span>
            </button>
          )}

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>

          {(isSuperAdmin || isAdmin || isTeacher || isStaff) && (
            <>
              <button
                onClick={onOpenManualAttendance}
                className="flex items-center gap-1.5 rounded-xl border border-blue-300 dark:border-blue-700 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 px-3.5 py-2 text-xs font-bold hover:bg-blue-100 transition"
              >
                <UserCheck className="w-4 h-4" />
                <span>Manual Entry</span>
              </button>

              {onOpenDailyRegister && (
                <button
                  onClick={onOpenDailyRegister}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3.5 py-2 text-xs font-bold hover:bg-slate-50 transition shadow-xs"
                >
                  <CalendarCheck className="w-4 h-4 text-blue-600" />
                  <span>Daily Register</span>
                </button>
              )}

              <button
                onClick={onOpenQRScanner}
                id="btn-open-scanner-main"
                className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-xs font-bold shadow-xs transition active:scale-95"
              >
                <QrCode className="w-4 h-4" />
                <span>Scan Attendance QR</span>
              </button>
            </>
          )}
        </div>
      </div>

      {syncedCount !== null && (
        <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Successfully synchronized {syncedCount} offline attendance records!</span>
        </div>
      )}

      {/* Active Sessions Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {sessions.slice(0, 3).map(session => {
          const sessionAttendance = attendanceLogs.filter(a => a.sessionId === session.sessionId);
          return (
            <div
              key={session.sessionId}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  session.status === 'OPEN'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}>
                  {session.status}
                </span>
                <span className="text-xs text-slate-400 font-semibold">{session.date}</span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                  {session.className}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {session.startTime} - {session.endTime} &bull; Room: {session.room}
                </p>
                <p className="text-[10px] text-blue-600 font-semibold mt-0.5">
                  Teacher: {session.teacherName}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Attendance</span>
                  <p className="text-sm font-black text-slate-900 dark:text-white">
                    {sessionAttendance.length} Present
                  </p>
                </div>
                <button
                  onClick={onOpenQRScanner}
                  className="rounded-xl bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 px-3 py-1.5 text-xs font-bold transition"
                >
                  Scan In
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search attendance by student name, ID, class..."
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-white"
          >
            <option value="ALL">All Classes</option>
            {classes.map(c => (
              <option key={c.classId} value={c.classId}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="PRESENT">Present</option>
            <option value="LATE">Late</option>
            <option value="EXCUSED">Excused</option>
          </select>
        </div>
      </div>

      {/* Attendance Log Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Student</th>
                <th className="px-4 py-3.5">Class / Subject</th>
                <th className="px-4 py-3.5">Date & Time</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Method</th>
                <th className="px-5 py-3.5 text-right">Verified By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400">
                    No attendance records found.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.attendanceId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="px-5 py-3.5">
                      {onViewStudentProfile ? (
                        <button
                          onClick={() => onViewStudentProfile(log.studentId)}
                          className="font-bold text-slate-900 dark:text-white hover:text-blue-600 text-left transition"
                        >
                          {log.studentName}
                        </button>
                      ) : (
                        <p className="font-bold text-slate-900 dark:text-white">
                          {log.studentName}
                        </p>
                      )}
                      <p className="text-[11px] text-blue-600 font-semibold">{log.studentId}</p>
                    </td>

                    <td className="px-4 py-3.5 truncate max-w-[200px]">
                      {log.className}
                    </td>

                    <td className="px-4 py-3.5">
                      <span>{log.date}</span>
                      <p className="text-[10px] text-slate-400">
                        {new Date(log.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </td>

                    <td className="px-4 py-3.5">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        log.status === 'PRESENT'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : log.status === 'LATE'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        {log.status}
                      </span>
                    </td>

                    <td className="px-4 py-3.5">
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {log.attendanceMethod === 'QR' ? 'QR Scanner' : 'Manual Entry'}
                      </span>
                    </td>

                    <td className="px-5 py-3.5 text-right font-medium">
                      {log.markedByName}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
