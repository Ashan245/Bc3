import React, { useState } from 'react';
import {
  CalendarCheck,
  Search,
  QrCode,
  Download,
  Printer,
  UserCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  FileSpreadsheet,
  Lock,
  ChevronDown,
  User,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { storageService } from '../services/storageService';
import { AttendanceStatus, ClassSession, Student } from '../types';

interface DailyRegisterViewProps {
  onOpenQRScanner: () => void;
  onViewStudentProfile: (studentId: string) => void;
}

export const DailyRegisterView: React.FC<DailyRegisterViewProps> = ({
  onOpenQRScanner,
  onViewStudentProfile,
}) => {
  const { currentUser, role, isSuperAdmin, isAdmin, isStaff, isTeacher } = useAuth();
  const { settings } = useSettings();

  const allSessions = storageService.getClassSessions().filter(s => s.status !== 'CANCELLED');
  const classes = storageService.getClasses();
  const teachers = storageService.getTeachers();

  // Role-based visibility (Requirement 14):
  // Admin/Super Admin can see academy-wide attendance.
  // Teacher can only see assigned classes.
  // Staff sees classes permitted by role.
  const permittedClasses = isTeacher
    ? classes.filter(c => c.teacherId === currentUser?.userId || c.teacherName.toLowerCase().includes(currentUser?.name?.toLowerCase() || ''))
    : classes;

  const [selectedClassId, setSelectedClassId] = useState<string>(
    permittedClasses[0]?.classId || classes[0]?.classId || ''
  );

  const classSessions = allSessions.filter(s => s.classId === selectedClassId);
  const [selectedSessionId, setSelectedSessionId] = useState<string>(
    classSessions[0]?.sessionId || ''
  );

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | AttendanceStatus | 'UNMARKED'>('ALL');
  const [printMode, setPrintMode] = useState<boolean>(false);

  const currentClass = classes.find(c => c.classId === selectedClassId);
  const currentSession = classSessions.find(s => s.sessionId === selectedSessionId) || classSessions[0];
  const assignedTeacher = teachers.find(t => t.teacherId === currentClass?.teacherId);

  const enrolledStudents = storageService.getStudents(false).filter(
    s => s.classId === selectedClassId && s.status === 'ACTIVE'
  );

  const sessionAttendance = currentSession
    ? storageService.getAttendance().filter(a => a.sessionId === currentSession.sessionId)
    : [];

  const canAccessFinance = isSuperAdmin || isAdmin || isStaff;

  // Counters
  const totalEnrolled = enrolledStudents.length;
  const presentCount = sessionAttendance.filter(a => a.status === 'PRESENT').length;
  const lateCount = sessionAttendance.filter(a => a.status === 'LATE').length;
  const absentCount = sessionAttendance.filter(a => a.status === 'ABSENT').length;
  const excusedCount = sessionAttendance.filter(a => a.status === 'EXCUSED').length;
  const unmarkedCount = Math.max(0, totalEnrolled - sessionAttendance.length);

  // Close session & mark remaining absents (Requirement 28)
  const handleCloseSession = () => {
    if (!currentSession) return;
    if (
      window.confirm(
        `Are you sure you want to close this session? All ${unmarkedCount} unmarked student(s) will automatically be recorded as ABSENT.`
      )
    ) {
      storageService.closeSessionAndMarkAbsents(
        currentSession.sessionId,
        currentUser?.userId || 'SYS',
        currentUser?.name || 'Staff'
      );
      // force update
      setSelectedSessionId(currentSession.sessionId);
    }
  };

  // Quick Inline Status Update
  const handleInlineStatusChange = (student: Student, newStatus: AttendanceStatus) => {
    if (!currentSession) return;
    const existing = sessionAttendance.find(a => a.studentId === student.studentId);
    if (existing) {
      storageService.updateAttendanceStatus(existing.attendanceId, newStatus, currentUser?.name || 'Staff');
    } else {
      storageService.recordAttendance({
        studentId: student.studentId,
        studentName: student.fullName,
        classId: currentSession.classId,
        className: currentSession.className,
        sessionId: currentSession.sessionId,
        date: currentSession.date,
        status: newStatus,
        attendanceMethod: 'MANUAL_SEARCH',
        markedBy: currentUser?.userId || 'SYS',
        markedByName: currentUser?.name || 'Staff',
        markedByRole: role,
        markedAt: new Date().toISOString(),
      });
    }
    // refresh state
    setSelectedSessionId(currentSession.sessionId);
  };

  // Export CSV (Requirement 15)
  const exportCSV = () => {
    if (!currentSession) return;
    const headers = ['Index', 'Student ID', 'Student Name', 'Grade', 'Class', 'Status', 'Check-in Time', 'Method', 'Verified By'];
    const rows = enrolledStudents.map((s, idx) => {
      const att = sessionAttendance.find(a => a.studentId === s.studentId);
      return [
        idx + 1,
        s.studentId,
        `"${s.fullName}"`,
        s.grade,
        `"${s.className}"`,
        att?.status || 'UNMARKED',
        att ? new Date(att.markedAt).toLocaleTimeString() : '-',
        att?.attendanceMethod || '-',
        `"${att?.markedByName || '-'}"`,
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Daily_Register_${currentClass?.name}_${currentSession.date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered list
  const filteredStudents = enrolledStudents.filter(s => {
    const q = searchQuery.toLowerCase();
    const matchSearch = s.fullName.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q);
    if (!matchSearch) return false;

    if (statusFilter === 'ALL') return true;
    const att = sessionAttendance.find(a => a.studentId === s.studentId);
    if (statusFilter === 'UNMARKED') return !att;
    return att?.status === statusFilter;
  });

  // Requirement 16: Printable Daily Register
  if (printMode && currentSession) {
    return (
      <div className="bg-white text-slate-900 p-8 max-w-4xl mx-auto space-y-6 print:p-0">
        <div className="flex justify-between items-center border-b pb-4 no-print">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold"
          >
            <Printer className="w-4 h-4" />
            <span>Print Now</span>
          </button>
          <button
            onClick={() => setPrintMode(false)}
            className="text-xs text-slate-600 font-bold border px-3 py-1.5 rounded-xl"
          >
            Exit Print View
          </button>
        </div>

        <div className="text-center space-y-1">
          <h1 className="text-xl font-black uppercase tracking-wider">{settings.academyName}</h1>
          <h2 className="text-base font-bold underline">DAILY STUDENT REGISTER</h2>
        </div>

        <div className="grid grid-cols-2 text-xs border p-4 rounded-xl gap-2">
          <div>Date: <strong>{currentSession.date}</strong></div>
          <div>Grade: <strong>{currentClass?.grade}</strong></div>
          <div>Class: <strong>{currentClass?.name}</strong></div>
          <div>Teacher: <strong>{currentSession.teacherName}</strong></div>
          <div>Session Time: <strong>{currentSession.startTime} – {currentSession.endTime}</strong></div>
          <div>Room: <strong>{currentSession.room}</strong></div>
        </div>

        <div className="flex justify-between text-xs bg-slate-100 p-2 rounded-lg font-bold">
          <span>Enrolled: {totalEnrolled}</span>
          <span>Present: {presentCount}</span>
          <span>Late: {lateCount}</span>
          <span>Absent: {absentCount}</span>
          <span>Excused: {excusedCount}</span>
        </div>

        <table className="w-full text-xs border border-collapse">
          <thead>
            <tr className="bg-slate-100 border-b text-left">
              <th className="p-2 border">#</th>
              <th className="p-2 border">Student ID</th>
              <th className="p-2 border">Student Full Name</th>
              <th className="p-2 border">Status</th>
              <th className="p-2 border">Time</th>
              <th className="p-2 border">Method</th>
            </tr>
          </thead>
          <tbody>
            {enrolledStudents.map((s, i) => {
              const att = sessionAttendance.find(a => a.studentId === s.studentId);
              return (
                <tr key={s.studentId} className="border-b">
                  <td className="p-2 border">{i + 1}</td>
                  <td className="p-2 border font-mono">{s.studentId}</td>
                  <td className="p-2 border font-semibold">{s.fullName}</td>
                  <td className="p-2 border font-bold">
                    {att?.status || 'ABSENT'}
                  </td>
                  <td className="p-2 border font-mono">
                    {att ? new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                  </td>
                  <td className="p-2 border">{att?.attendanceMethod || '-'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Signature Area */}
        <div className="grid grid-cols-2 pt-16 text-xs text-center gap-12">
          <div>
            <div className="border-t border-slate-400 w-48 mx-auto pt-1 font-bold">
              Teacher Signature
            </div>
            <p className="text-slate-500 text-[10px]">{currentSession.teacherName}</p>
          </div>
          <div>
            <div className="border-t border-slate-400 w-48 mx-auto pt-1 font-bold">
              Admin / Office Signature
            </div>
            <p className="text-slate-500 text-[10px]">Verified Official Copy</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <CalendarCheck className="w-6 h-6 text-blue-600" />
            <span>Daily Class Register</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time verified check-in log, attendance reconciliation & register export
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenQRScanner}
            className="flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-bold shadow-xs transition"
          >
            <QrCode className="w-4 h-4" />
            <span>Launch QR Scanner</span>
          </button>
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 text-slate-700 dark:text-slate-200 px-3 py-2 text-xs font-bold transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setPrintMode(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 text-slate-700 dark:text-slate-200 px-3 py-2 text-xs font-bold transition shadow-xs"
          >
            <Printer className="w-3.5 h-3.5 text-blue-600" />
            <span>Print Register</span>
          </button>
        </div>
      </div>

      {/* Class & Session Selector Bar */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
              Select Class:
            </label>
            <select
              value={selectedClassId}
              onChange={e => {
                setSelectedClassId(e.target.value);
                const s = allSessions.find(sess => sess.classId === e.target.value);
                if (s) setSelectedSessionId(s.sessionId);
              }}
              className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-900 dark:text-white"
            >
              {permittedClasses.map(c => (
                <option key={c.classId} value={c.classId}>
                  {c.grade} - {c.name} ({c.teacherName})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
              Session:
            </label>
            <select
              value={selectedSessionId}
              onChange={e => setSelectedSessionId(e.target.value)}
              className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-900 dark:text-white"
            >
              {classSessions.map(s => (
                <option key={s.sessionId} value={s.sessionId}>
                  {s.date} ({s.startTime} - {s.endTime}) - {s.status}
                </option>
              ))}
            </select>
          </div>
        </div>

        {currentSession && currentSession.status === 'OPEN' && (
          <button
            onClick={handleCloseSession}
            className="flex items-center gap-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-200 dark:border-rose-900 px-3.5 py-1.5 text-xs font-bold transition"
            title="Closes session and marks un-scanned students as Absent"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Close Session & Mark Absents ({unmarkedCount})</span>
          </button>
        )}
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Enrolled</span>
          <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{totalEnrolled}</p>
        </div>
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
          <span className="text-[10px] uppercase font-bold text-emerald-800 dark:text-emerald-300">Present</span>
          <p className="text-xl font-black text-emerald-950 dark:text-emerald-100 mt-1">{presentCount}</p>
        </div>
        <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
          <span className="text-[10px] uppercase font-bold text-amber-800 dark:text-amber-300">Late</span>
          <p className="text-xl font-black text-amber-950 dark:text-amber-100 mt-1">{lateCount}</p>
        </div>
        <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
          <span className="text-[10px] uppercase font-bold text-rose-800 dark:text-rose-300">Absent</span>
          <p className="text-xl font-black text-rose-950 dark:text-rose-100 mt-1">{absentCount}</p>
        </div>
        <div className="p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800">
          <span className="text-[10px] uppercase font-bold text-blue-800 dark:text-blue-300">Excused</span>
          <p className="text-xl font-black text-blue-950 dark:text-blue-100 mt-1">{excusedCount}</p>
        </div>
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500">Unmarked</span>
          <p className="text-xl font-black text-slate-700 dark:text-slate-300 mt-1">{unmarkedCount}</p>
        </div>
      </div>

      {/* Filter & Search Ribbon */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {(['ALL', 'PRESENT', 'LATE', 'ABSENT', 'EXCUSED', 'UNMARKED'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${
                statusFilter === tab
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search student name or ID..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Student Register Table */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-400">
              <tr>
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4">Attendance Status</th>
                <th className="py-3 px-4">Check-in Time</th>
                <th className="py-3 px-4">Method</th>
                {canAccessFinance && <th className="py-3 px-4">Fee Status</th>}
                <th className="py-3 px-4 text-right">Quick Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No students found matching this criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s, idx) => {
                  const att = sessionAttendance.find(a => a.studentId === s.studentId);
                  const feeStatus = canAccessFinance ? storageService.calculateStudentFeeStatus(s.studentId) : null;

                  return (
                    <tr key={s.studentId} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={s.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                            alt={s.fullName}
                            className="w-8 h-8 rounded-xl object-cover"
                          />
                          <div>
                            <button
                              onClick={() => onViewStudentProfile(s.studentId)}
                              className="font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 text-left block"
                            >
                              {s.fullName}
                            </button>
                            <span className="text-[10px] text-slate-400">{s.school}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-blue-600">
                        {s.studentId}
                      </td>
                      <td className="py-3 px-4">
                        {att ? (
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-black ${
                            att.status === 'PRESENT'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : att.status === 'LATE'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}>
                            {att.status}
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 dark:bg-slate-800">
                            NOT MARKED
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {att ? new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                          {att?.attendanceMethod || '-'}
                        </span>
                      </td>
                      {canAccessFinance && (
                        <td className="py-3 px-4">
                          {feeStatus ? (
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              feeStatus.paymentStatus === 'PAID'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : feeStatus.paymentStatus === 'PARTIAL'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            }`}>
                              {feeStatus.paymentStatus} (Rs. {feeStatus.outstandingBalance.toLocaleString()})
                            </span>
                          ) : '-'}
                        </td>
                      )}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleInlineStatusChange(s, 'PRESENT')}
                            className="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200 text-[10px] font-bold transition"
                            title="Mark Present"
                          >
                            P
                          </button>
                          <button
                            onClick={() => handleInlineStatusChange(s, 'LATE')}
                            className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 text-[10px] font-bold transition"
                            title="Mark Late"
                          >
                            L
                          </button>
                          <button
                            onClick={() => handleInlineStatusChange(s, 'ABSENT')}
                            className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200 text-[10px] font-bold transition"
                            title="Mark Absent"
                          >
                            A
                          </button>
                          <button
                            onClick={() => onViewStudentProfile(s.studentId)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition"
                            title="View Student Profile"
                          >
                            <User className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
