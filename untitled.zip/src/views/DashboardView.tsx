import React, { useState } from 'react';
import {
  Users,
  CalendarCheck,
  CreditCard,
  AlertTriangle,
  TrendingUp,
  Clock,
  CheckCircle2,
  QrCode,
  UserPlus,
  Receipt as ReceiptIcon,
  ChevronRight,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { storageService } from '../services/storageService';
import { ClassSession, Fee, Receipt } from '../types';

interface DashboardViewProps {
  onOpenQRScanner: () => void;
  onOpenManualAttendance: () => void;
  onOpenNewStudent: () => void;
  onSelectTab: (tab: string) => void;
  onOpenPayment: (fee: Fee) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenQRScanner,
  onOpenManualAttendance,
  onOpenNewStudent,
  onSelectTab,
  onOpenPayment,
}) => {
  const { role, isSuperAdmin, isAdmin, isTeacher, isStaff, isStudent, isParent } = useAuth();
  const { settings, t } = useSettings();

  const students = storageService.getStudents(false);
  const activeStudents = students.filter(s => s.status === 'ACTIVE');
  const sessions = storageService.getClassSessions();
  const todaySessions = sessions.filter(s => s.status !== 'CANCELLED');
  const attendanceLogs = storageService.getAttendance();
  const fees = storageService.getFees();
  const payments = storageService.getPayments();
  const announcements = storageService.getAnnouncements();

  // Metrics calculation
  const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOverdue = fees
    .filter(f => f.status === 'UNPAID' || f.status === 'OVERDUE' || f.status === 'PARTIAL')
    .reduce((sum, f) => sum + f.balance, 0);

  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayAttendance = attendanceLogs.filter(a => a.date === todayDateStr || a.markedAt.startsWith(todayDateStr));
  const attendanceRate = activeStudents.length > 0 ? Math.round((todayAttendance.length / activeStudents.length) * 100) : 0;

  const unpaidFeeAlerts = fees.filter(f => f.status === 'OVERDUE' || f.status === 'UNPAID').slice(0, 4);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 p-6 md:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-blue-200 backdrop-blur-xs mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Academic Term 3 &bull; Colombo Campus</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
            {settings.academyName}
          </h1>
          <p className="mt-2 text-xs md:text-sm text-blue-100 leading-relaxed max-w-xl">
            {settings.tagline || 'Excellence in English Language, Literature & Professional Communication'}
          </p>

          <div className="mt-5 flex flex-wrap gap-2.5">
            {(isSuperAdmin || isAdmin || isTeacher || isStaff) && (
              <>
                <button
                  onClick={onOpenQRScanner}
                  id="btn-dash-scan-qr"
                  className="flex items-center gap-2 rounded-xl bg-white text-blue-950 hover:bg-blue-50 px-4 py-2 text-xs font-bold shadow-md transition active:scale-95"
                >
                  <QrCode className="w-4 h-4 text-blue-600" />
                  <span>Scan Attendance QR</span>
                </button>

                <button
                  onClick={onOpenManualAttendance}
                  id="btn-dash-manual-attendance"
                  className="flex items-center gap-2 rounded-xl bg-blue-700/60 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-semibold border border-blue-400/40 transition"
                >
                  <CalendarCheck className="w-4 h-4" />
                  <span>Manual Attendance</span>
                </button>
              </>
            )}

            {(isSuperAdmin || isAdmin) && (
              <button
                onClick={onOpenNewStudent}
                id="btn-dash-new-student"
                className="flex items-center gap-2 rounded-xl bg-blue-700/60 hover:bg-blue-700 text-white px-3.5 py-2 text-xs font-semibold border border-blue-400/40 transition"
              >
                <UserPlus className="w-4 h-4" />
                <span>Register Student</span>
              </button>
            )}
          </div>
        </div>

        {/* Decorative background circle */}
        <div className="absolute -right-16 -bottom-16 w-64 h-64 rounded-full bg-white/5 pointer-events-none" />
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 md:gap-4">
        {/* Total Students */}
        <div
          onClick={() => onSelectTab('students')}
          className="cursor-pointer rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-blue-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Active Students
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              {activeStudents.length}
            </h3>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
              100% enrolled across Grades 6-11
            </p>
          </div>
        </div>

        {/* Attendance Rate */}
        <div
          onClick={() => onSelectTab('attendance')}
          className="cursor-pointer rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Today's Attendance
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              {todayAttendance.length}{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({attendanceRate}%)
              </span>
            </h3>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
              Across active sessions
            </p>
          </div>
        </div>

        {/* Collected Fees */}
        <div
          onClick={() => onSelectTab('finance')}
          className="cursor-pointer rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-purple-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Total Collections
            </span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              Rs. {totalPaid.toLocaleString()}
            </h3>
            <p className="text-[11px] text-purple-600 font-semibold mt-0.5">
              {payments.length} verified receipts issued
            </p>
          </div>
        </div>

        {/* Overdue Balance */}
        <div
          onClick={() => onSelectTab('finance')}
          className="cursor-pointer rounded-2xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-red-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Outstanding Fees
            </span>
            <div className="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/60 text-red-600 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-red-600 dark:text-red-400">
              Rs. {totalOverdue.toLocaleString()}
            </h3>
            <p className="text-[11px] text-red-600 font-semibold mt-0.5">
              {unpaidFeeAlerts.length} pending student accounts
            </p>
          </div>
        </div>
      </div>

      {/* Main Content Split: Sessions & Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Classes & Recent Attendance */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Class Sessions */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  Scheduled & Open Class Sessions
                </h3>
                <p className="text-[11px] text-slate-500">
                  Select a class to scan attendance or view enrolled students
                </p>
              </div>
              <button
                onClick={() => onSelectTab('classes')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <span>All Classes</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {todaySessions.slice(0, 3).map(session => (
                <div
                  key={session.sessionId}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        session.status === 'OPEN'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}>
                        {session.status}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {session.className}
                      </h4>
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
                      <span>{session.date} &bull; {session.startTime} - {session.endTime}</span>
                      <span>Room: {session.room}</span>
                      <span>Teacher: {session.teacherName}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={onOpenQRScanner}
                      className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Take Attendance</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Live Attendance Logs */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  Live Attendance Stream
                </h3>
                <p className="text-[11px] text-slate-500">
                  Real-time QR verification and audit logs
                </p>
              </div>
              <button
                onClick={() => onSelectTab('attendance')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <span>Full History</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {attendanceLogs.slice(0, 5).map(att => (
                <div key={att.attendanceId} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">
                        {att.studentName}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {att.className} &bull; Verified via {att.attendanceMethod}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      att.status === 'PRESENT'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}>
                      {att.status}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      {new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Fee Alerts & Announcements */}
        <div className="space-y-6">
          {/* Overdue Fee Follow-up Card */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Fee Payment Reminders
              </h3>
              <span className="text-[10px] bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300 px-2 py-0.5 rounded-full font-bold">
                {unpaidFeeAlerts.length} Pending
              </span>
            </div>

            <div className="space-y-2.5">
              {unpaidFeeAlerts.map(fee => (
                <div
                  key={fee.feeId}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-xs flex items-center justify-between"
                >
                  <div className="overflow-hidden pr-2">
                    <p className="font-bold text-slate-900 dark:text-white truncate">
                      {fee.studentName}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {fee.billingMonth} &bull; Due: {fee.dueDate}
                    </p>
                    <p className="text-xs font-black text-red-600 dark:text-red-400 mt-0.5">
                      Rs. {fee.balance.toLocaleString()}
                    </p>
                  </div>

                  {(isSuperAdmin || isAdmin || isStaff) && (
                    <button
                      onClick={() => onOpenPayment(fee)}
                      className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 text-xs font-bold transition shadow-xs shrink-0"
                    >
                      Record Fee
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Academy Announcements Feed */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
              Academy Notice Board
            </h3>
            <div className="space-y-3">
              {announcements.map(ann => (
                <div
                  key={ann.announcementId}
                  className="p-3.5 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/50 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 dark:text-white">
                      {ann.title}
                    </h4>
                    {ann.isUrgent && (
                      <span className="text-[9px] bg-red-500 text-white font-bold px-1.5 py-0.5 rounded">
                        URGENT
                      </span>
                    )}
                  </div>
                  <p className="mt-1.5 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                    {ann.message}
                  </p>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                    <span>By: {ann.authorName}</span>
                    <span>{ann.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
