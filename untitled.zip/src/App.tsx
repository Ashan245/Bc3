import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SettingsProvider, useSettings } from './contexts/SettingsContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { QRScannerModal } from './components/QRScannerModal';
import { ManualAttendanceModal } from './components/ManualAttendanceModal';
import { FullScreenQRModal } from './components/FullScreenQRModal';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { StudentFormModal } from './components/StudentFormModal';
import { DashboardView } from './views/DashboardView';
import { StudentsView } from './views/StudentsView';
import { AttendanceView } from './views/AttendanceView';
import { ClassesView } from './views/ClassesView';
import { FinanceView } from './views/FinanceView';
import { LearningView } from './views/LearningView';
import { StudentPortalView } from './views/StudentPortalView';
import { ParentPortalView } from './views/ParentPortalView';
import { SettingsView } from './views/SettingsView';
import { DailyRegisterView } from './views/DailyRegisterView';
import { StudentProfileModal } from './components/StudentProfileModal';
import { Student, Fee, Receipt } from './types';
import { storageService } from './services/storageService';

const AppContent: React.FC = () => {
  const { role, isStudent, isParent } = useAuth();
  const { settings } = useSettings();

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Modals state
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [isManualAttendanceOpen, setIsManualAttendanceOpen] = useState(false);
  const [isStudentQROpen, setIsStudentQROpen] = useState(false);
  const [qrStudentId, setQrStudentId] = useState<string>('STU-000001');
  const [paymentFee, setPaymentFee] = useState<Fee | null>(null);
  const [receiptToView, setReceiptToView] = useState<Receipt | null>(null);
  const [isStudentFormOpen, setIsStudentFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [selectedProfileStudentId, setSelectedProfileStudentId] = useState<string | null>(null);

  // Switch initial tab if role changes
  useEffect(() => {
    if (isStudent && activeTab === 'students') {
      setActiveTab('student-portal');
    } else if (isParent && (activeTab === 'students' || activeTab === 'finance')) {
      setActiveTab('parent-portal');
    }
  }, [role, isStudent, isParent]);

  const handleOpenStudentQR = (studentId?: string) => {
    if (studentId) {
      setQrStudentId(studentId);
    } else {
      const firstStudent = storageService.getStudents(false)[0];
      setQrStudentId(firstStudent ? firstStudent.studentId : 'STU-000001');
    }
    setIsStudentQROpen(true);
  };

  const handleOpenNewStudent = () => {
    setEditingStudent(null);
    setIsStudentFormOpen(true);
  };

  const handleOpenEditStudent = (student: Student | null) => {
    setEditingStudent(student);
    if (student) {
      setIsStudentFormOpen(true);
    }
  };

  const handlePaymentSuccess = (receipt: Receipt) => {
    setPaymentFee(null);
    setReceiptToView(receipt);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
      {/* Header Bar */}
      <Header
        onOpenSidebar={() => setIsSidebarOpen(true)}
        onOpenQRScanner={() => setIsQRScannerOpen(true)}
        onOpenStudentQR={() => handleOpenStudentQR()}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />

        {/* Main Viewport */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 pb-24 md:pb-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenQRScanner={() => setIsQRScannerOpen(true)}
              onOpenManualAttendance={() => setIsManualAttendanceOpen(true)}
              onOpenNewStudent={handleOpenNewStudent}
              onSelectTab={setActiveTab}
              onOpenPayment={fee => setPaymentFee(fee)}
            />
          )}

          {activeTab === 'students' && (
            <StudentsView
              onOpenStudentQR={handleOpenStudentQR}
              onOpenNewStudent={handleOpenNewStudent}
              editingStudent={editingStudent}
              setEditingStudent={handleOpenEditStudent}
              onViewStudentProfile={studentId => setSelectedProfileStudentId(studentId)}
            />
          )}

          {activeTab === 'attendance' && (
            <AttendanceView
              onOpenQRScanner={() => setIsQRScannerOpen(true)}
              onOpenManualAttendance={() => setIsManualAttendanceOpen(true)}
              onOpenDailyRegister={() => setActiveTab('daily-register')}
              onViewStudentProfile={studentId => setSelectedProfileStudentId(studentId)}
            />
          )}

          {activeTab === 'daily-register' && (
            <DailyRegisterView
              onOpenQRScanner={() => setIsQRScannerOpen(true)}
              onViewStudentProfile={studentId => setSelectedProfileStudentId(studentId)}
            />
          )}

          {activeTab === 'classes' && (
            <ClassesView onOpenQRScanner={() => setIsQRScannerOpen(true)} />
          )}

          {activeTab === 'finance' && (
            <FinanceView
              onOpenPayment={fee => setPaymentFee(fee)}
              onOpenReceipt={receipt => setReceiptToView(receipt)}
            />
          )}

          {activeTab === 'learning' && <LearningView />}

          {activeTab === 'student-portal' && (
            <StudentPortalView
              onOpenStudentQR={handleOpenStudentQR}
              onOpenReceipt={receipt => setReceiptToView(receipt)}
            />
          )}

          {activeTab === 'parent-portal' && (
            <ParentPortalView
              onOpenReceipt={receipt => setReceiptToView(receipt)}
              onOpenStudentQR={handleOpenStudentQR}
            />
          )}

          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Mobile Bottom Bar for one-handed mobile phone usage */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQRScanner={() => setIsQRScannerOpen(true)}
        onOpenStudentQR={() => handleOpenStudentQR()}
      />

      {/* Camera / Simulation QR Scanner Modal */}
      <QRScannerModal
        isOpen={isQRScannerOpen}
        onClose={() => setIsQRScannerOpen(false)}
        onViewStudentProfile={studentId => setSelectedProfileStudentId(studentId)}
        onOpenPayment={fee => setPaymentFee(fee)}
        onOpenReceipt={receipt => setReceiptToView(receipt)}
      />

      {/* 14-Tab Comprehensive Student Profile Dashboard */}
      <StudentProfileModal
        isOpen={selectedProfileStudentId !== null}
        onClose={() => setSelectedProfileStudentId(null)}
        studentId={selectedProfileStudentId || ''}
        onOpenStudentQR={handleOpenStudentQR}
        onOpenPayment={fee => setPaymentFee(fee)}
        onOpenReceipt={receipt => setReceiptToView(receipt)}
        onEditStudent={handleOpenEditStudent}
      />

      {/* Manual Attendance Search Modal */}
      <ManualAttendanceModal
        isOpen={isManualAttendanceOpen}
        onClose={() => setIsManualAttendanceOpen(false)}
      />

      {/* Student High-Contrast Full-Screen QR & ID Card Modal */}
      <FullScreenQRModal
        isOpen={isStudentQROpen}
        onClose={() => setIsStudentQROpen(false)}
        studentId={qrStudentId}
      />

      {/* Record Fee Payment Modal */}
      <PaymentModal
        isOpen={paymentFee !== null}
        onClose={() => setPaymentFee(null)}
        fee={paymentFee}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Official Receipt Modal */}
      <ReceiptModal
        isOpen={receiptToView !== null}
        onClose={() => setReceiptToView(null)}
        receipt={receiptToView}
      />

      {/* Student Form Modal (Register / Edit) */}
      <StudentFormModal
        isOpen={isStudentFormOpen}
        onClose={() => {
          setIsStudentFormOpen(false);
          setEditingStudent(null);
        }}
        student={editingStudent}
        onSaved={() => {
          // Trigger refresh if needed
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <SettingsProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </SettingsProvider>
    </ThemeProvider>
  );
}
