import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile, UserRole } from '../types';
import { demoUsers } from '../services/seedService';
import { auth, isFirebaseConfigured } from '../firebase/config';
import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole;
  isFirebaseActive: boolean;
  switchDemoRole: (role: UserRole) => void;
  loginWithEmail: (email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isTeacher: boolean;
  isStaff: boolean;
  isStudent: boolean;
  isParent: boolean;
  canManageStudents: boolean;
  canMarkAttendance: boolean;
  canViewFinancials: boolean;
  canManageLMS: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('eap_active_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return demoUsers[0]; // Default to Super Admin
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('eap_active_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  // Hook Firebase Auth listener if configured
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) return;

    const unsubscribe = onAuthStateChanged(auth, (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        // Check if there is an existing demo or mapped profile
        const matched = demoUsers.find(u => u.email.toLowerCase() === fbUser.email?.toLowerCase());
        if (matched) {
          setCurrentUser(matched);
        } else {
          setCurrentUser({
            userId: fbUser.uid,
            email: fbUser.email || 'user@englishacademypro.lk',
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Academy User',
            role: 'ADMIN',
            isActive: true,
            createdAt: new Date().toISOString(),
          });
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const switchDemoRole = (newRole: UserRole) => {
    const target = demoUsers.find(u => u.role === newRole) || {
      userId: `usr-${newRole.toLowerCase()}`,
      email: `${newRole.toLowerCase()}@englishacademypro.lk`,
      name: `${newRole.replace('_', ' ')} Account`,
      role: newRole,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    setCurrentUser(target);
  };

  const loginWithEmail = async (email: string, pass: string): Promise<boolean> => {
    if (isFirebaseConfigured && auth) {
      try {
        await signInWithEmailAndPassword(auth, email, pass);
        return true;
      } catch (err) {
        console.error('Firebase Auth sign-in failed:', err);
        throw err;
      }
    } else {
      // Local demo sign in
      const match = demoUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (match) {
        setCurrentUser(match);
        return true;
      }
      return true; // allow demo entry
    }
  };

  const logout = () => {
    if (isFirebaseConfigured && auth) {
      firebaseSignOut(auth).catch(err => console.warn('Signout warning:', err));
    }
    // Switch to student or stay logged out
    setCurrentUser(demoUsers[4]); // switch to student for browsing or allow re-selection
  };

  const role = currentUser?.role || 'STUDENT';
  const isSuperAdmin = role === 'SUPER_ADMIN';
  const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';
  const isTeacher = role === 'TEACHER';
  const isStaff = role === 'STAFF';
  const isStudent = role === 'STUDENT';
  const isParent = role === 'PARENT';

  const canManageStudents = isSuperAdmin || isAdmin || isStaff;
  const canMarkAttendance = isSuperAdmin || isAdmin || isTeacher || isStaff;
  const canViewFinancials = isSuperAdmin || isAdmin || isStaff;
  const canManageLMS = isSuperAdmin || isAdmin || isTeacher;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role,
        isFirebaseActive: isFirebaseConfigured,
        switchDemoRole,
        loginWithEmail,
        logout,
        isSuperAdmin,
        isAdmin,
        isTeacher,
        isStaff,
        isStudent,
        isParent,
        canManageStudents,
        canMarkAttendance,
        canViewFinancials,
        canManageLMS,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
