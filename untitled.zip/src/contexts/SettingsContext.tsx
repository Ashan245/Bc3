import React, { createContext, useContext, useState } from 'react';
import { AcademySettings } from '../types';
import { storageService } from '../services/storageService';
import { Language, translations } from '../i18n/translations';

interface SettingsContextType {
  settings: AcademySettings;
  updateSettings: (newSettings: Partial<AcademySettings>, actor?: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
}

const SettingsContext = createContext<SettingsContextType | null>(null);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AcademySettings>(() => storageService.getSettings());
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('eap_language') as Language;
    if (saved && (saved === 'en' || saved === 'si' || saved === 'ta')) return saved;
    return settings.language || 'en';
  });

  const updateSettings = (newSettings: Partial<AcademySettings>, actor: string = 'Admin') => {
    const updated = { ...settings, ...newSettings };
    storageService.saveSettings(updated, actor);
    setSettings(updated);
    if (newSettings.language && newSettings.language !== language) {
      setLanguageState(newSettings.language);
      localStorage.setItem('eap_language', newSettings.language);
    }
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('eap_language', lang);
    updateSettings({ language: lang });
  };

  const t = translations[language] || translations.en;

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, language, setLanguage, t }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
};
