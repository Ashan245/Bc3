import React, { useState } from 'react';
import {
  Menu,
  Moon,
  Sun,
  Globe,
  Bell,
  UserCheck,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { PWAInstallButton } from './PWAInstallButton';
import { UserRole } from '../types';
import { storageService } from '../services/storageService';

export const Header: React.FC<{
  onToggleSidebar: () => void;
  activeTab: string;
}> = ({ onToggleSidebar }) => {
  const { currentUser, role, switchDemoRole, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const { settings, language, setLanguage, t } = useSettings();

  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const notifications = storageService.getNotifications(currentUser?.userId);
  const unreadCount = notifications.filter(n => !n.read).length;

  const roles: { role: UserRole; label: string; desc: string }[] = [
    { role: 'SUPER_ADMIN', label: 'Super Admin', desc: 'Full institutional control' },
    { role: 'ADMIN', label: 'Admin', desc: 'Registrar & operations management' },
    { role: 'TEACHER', label: 'Teacher', desc: 'Class, attendance & LMS management' },
    { role: 'STAFF', label: 'Staff', desc: 'Front desk, fees & attendance' },
    { role: 'STUDENT', label: 'Student', desc: 'My QR, LMS, homework & fees' },
    { role: 'PARENT', label: 'Parent', desc: 'Linked child progress & receipts' },
  ];

  const getRoleBadgeColor = (r: UserRole) => {
    switch (r) {
      case 'SUPER_ADMIN':
        return 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800';
      case 'ADMIN':
        return 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800';
      case 'TEACHER':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800';
      case 'STAFF':
        return 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800';
      case 'STUDENT':
        return 'bg-cyan-100 text-cyan-800 border-cyan-300 dark:bg-cyan-950/60 dark:text-cyan-300 dark:border-cyan-800';
      case 'PARENT':
        return 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800';
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-4 md:px-6 backdrop-blur-md">
      {/* Left: Hamburger & Academy Brand */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          id="btn-sidebar-toggle"
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition md:hidden"
          title="Toggle Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold text-sm shadow-md overflow-hidden border border-blue-700">
            <img src={settings.logo || '/icon.svg'} alt={settings.academyName} className="w-full h-full object-cover" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white leading-none">
              {settings.academyName}
            </h1>
            <span className="text-[10px] font-semibold text-blue-600 dark:text-blue-400 tracking-wider uppercase">
              Pro Academy System
            </span>
          </div>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* PWA Install */}
        <PWAInstallButton className="hidden sm:flex" />

        {/* Role Switcher Button */}
        <div className="relative">
          <button
            onClick={() => {
              setShowRoleMenu(!showRoleMenu);
              setShowLangMenu(false);
              setShowNotifMenu(false);
            }}
            id="btn-role-switcher"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold border transition-all shadow-xs ${getRoleBadgeColor(
              role
            )}`}
            title="Switch User Role"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="capitalize">{role.replace('_', ' ')}</span>
          </button>

          {showRoleMenu && (
            <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-2 z-50 animate-in fade-in zoom-in-95">
              <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Switch Active Role (RBAC)
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                  Logged in as <strong className="text-blue-600">{currentUser?.name}</strong>
                </p>
              </div>
              <div className="py-1 space-y-1">
                {roles.map(r => (
                  <button
                    key={r.role}
                    onClick={() => {
                      switchDemoRole(r.role);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full flex items-start gap-2.5 px-3 py-2 rounded-xl text-left text-xs transition ${
                      role === r.role
                        ? 'bg-blue-50 text-blue-900 font-bold dark:bg-blue-950/60 dark:text-blue-200'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <UserCheck className={`w-4 h-4 mt-0.5 ${role === r.role ? 'text-blue-600' : 'text-slate-400'}`} />
                    <div>
                      <div className="font-semibold">{r.label}</div>
                      <div className="text-[11px] text-slate-400 font-normal">{r.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Language Switcher */}
        <div className="relative">
          <button
            onClick={() => {
              setShowLangMenu(!showLangMenu);
              setShowRoleMenu(false);
              setShowNotifMenu(false);
            }}
            id="btn-lang-switcher"
            className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition flex items-center gap-1 text-xs font-semibold"
            title="Switch Language"
          >
            <Globe className="w-4 h-4" />
            <span className="uppercase">{language}</span>
          </button>

          {showLangMenu && (
            <div className="absolute right-0 mt-2 w-44 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-1.5 z-50">
              <button
                onClick={() => {
                  setLanguage('en');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex justify-between items-center ${
                  language === 'en' ? 'bg-blue-50 dark:bg-blue-950 font-bold text-blue-600' : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span>English</span>
                {language === 'en' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => {
                  setLanguage('si');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex justify-between items-center ${
                  language === 'si' ? 'bg-blue-50 dark:bg-blue-950 font-bold text-blue-600' : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span>සිංහල (Sinhala)</span>
                {language === 'si' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => {
                  setLanguage('ta');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex justify-between items-center ${
                  language === 'ta' ? 'bg-blue-50 dark:bg-blue-950 font-bold text-blue-600' : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span>தமிழ் (Tamil)</span>
                {language === 'ta' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifMenu(!showNotifMenu);
              setShowRoleMenu(false);
              setShowLangMenu(false);
            }}
            id="btn-notification-bell"
            className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition relative"
            title="In-App Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 animate-ping" />
            )}
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500" />
            )}
          </button>

          {showNotifMenu && (
            <div className="absolute right-0 mt-2 w-80 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-2 z-50">
              <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Notifications</span>
                <span className="text-[10px] bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 px-2 py-0.5 rounded-full font-bold">
                  {unreadCount} new
                </span>
              </div>
              <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                {notifications.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400">No new notifications</div>
                ) : (
                  notifications.map(n => (
                    <div
                      key={n.notificationId}
                      onClick={() => storageService.markNotificationRead(n.notificationId)}
                      className={`p-3 text-xs cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60 transition ${
                        !n.read ? 'bg-blue-50/40 dark:bg-blue-950/20' : ''
                      }`}
                    >
                      <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-blue-600" />
                        {n.title}
                      </div>
                      <p className="mt-1 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                        {n.message}
                      </p>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        {new Date(n.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          id="btn-theme-toggle"
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition"
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
        </button>
      </div>
    </header>
  );
};
