import React from 'react';
import {
  LayoutDashboard,
  Users,
  QrCode,
  GraduationCap,
  CreditCard,
  User,
  HeartHandshake,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQRScanner: () => void;
  onOpenStudentQR: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenQRScanner,
  onOpenStudentQR,
}) => {
  const { role, isStudent, isParent, isTeacher, isStaff, isAdmin, isSuperAdmin } = useAuth();

  return (
    <div
      id="mobile-bottom-nav"
      className="fixed bottom-0 inset-x-0 z-30 flex h-16 items-center justify-around border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-2 md:hidden"
    >
      {/* 1. Dashboard */}
      <button
        onClick={() => setActiveTab('dashboard')}
        className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
          activeTab === 'dashboard'
            ? 'text-blue-600 dark:text-blue-400'
            : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
        }`}
      >
        <LayoutDashboard className="w-5 h-5 mb-0.5" />
        <span>Home</span>
      </button>

      {/* 2. Students or My Learning */}
      {isStudent ? (
        <button
          onClick={() => setActiveTab('learning')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'learning'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <GraduationCap className="w-5 h-5 mb-0.5" />
          <span>Lessons</span>
        </button>
      ) : isParent ? (
        <button
          onClick={() => setActiveTab('parent-portal')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'parent-portal'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <HeartHandshake className="w-5 h-5 mb-0.5" />
          <span>Child</span>
        </button>
      ) : (
        <button
          onClick={() => setActiveTab('students')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'students'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>Students</span>
        </button>
      )}

      {/* 3. Center Floating Action: Scan QR or Show My QR */}
      {isStudent ? (
        <button
          onClick={onOpenStudentQR}
          id="btn-mobile-center-qr"
          className="-mt-5 flex h-13 w-13 flex-col items-center justify-center rounded-2xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 transition active:scale-95"
          title="Show My QR ID"
        >
          <QrCode className="w-6 h-6" />
          <span className="text-[9px] font-bold mt-0.5">My QR</span>
        </button>
      ) : (
        <button
          onClick={onOpenQRScanner}
          id="btn-mobile-center-scan"
          className="-mt-5 flex h-13 w-13 flex-col items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/30 transition active:scale-95"
          title="Scan QR Attendance"
        >
          <QrCode className="w-6 h-6" />
          <span className="text-[9px] font-bold mt-0.5">Scan</span>
        </button>
      )}

      {/* 4. Learning or Attendance */}
      {(isSuperAdmin || isAdmin || isTeacher || isStaff) && (
        <button
          onClick={() => setActiveTab('attendance')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'attendance'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <GraduationCap className="w-5 h-5 mb-0.5" />
          <span>Classes</span>
        </button>
      )}

      {/* 5. Finance or Student Portal */}
      {isStudent ? (
        <button
          onClick={() => setActiveTab('student-portal')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'student-portal'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <User className="w-5 h-5 mb-0.5" />
          <span>Profile</span>
        </button>
      ) : (
        <button
          onClick={() => setActiveTab(isSuperAdmin || isAdmin || isStaff ? 'finance' : 'learning')}
          className={`flex flex-col items-center justify-center w-14 py-1 text-[10px] font-semibold transition ${
            activeTab === 'finance' || activeTab === 'learning'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <CreditCard className="w-5 h-5 mb-0.5" />
          <span>{isSuperAdmin || isAdmin || isStaff ? 'Fees' : 'LMS'}</span>
        </button>
      )}
    </div>
  );
};
