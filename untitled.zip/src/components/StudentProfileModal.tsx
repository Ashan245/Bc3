import React, { useState } from 'react';
import {
  X,
  User,
  CalendarCheck,
  CreditCard,
  Receipt as ReceiptIcon,
  GraduationCap,
  BookOpen,
  HelpCircle,
  Award,
  FileText,
  Users,
  FolderArchive,
  History as HistoryIcon,
  Clock,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  Download,
  Printer,
  Phone,
  Mail,
  School,
  Lock,
  ExternalLink,
  ShieldAlert,
  TrendingUp,
  Layers,
  ArrowRightLeft,
  Trash2,
  Plus,
  Activity as ActivityIcon,
  ShieldCheck,
} from 'lucide-react';
import { Student, CalculatedStudentFeeStatus, Receipt, Fee, StudentDocument, ClassTransferRecord } from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentId: string | null;
  onOpenStudentQR?: (studentId: string) => void;
  onOpenPayment?: (fee: Fee) => void;
  onOpenReceipt?: (receipt: Receipt) => void;
  onEditStudent?: (student: Student) => void;
  onSwitchStudent?: (studentId: string) => void;
}

type ProfileTab =
  | 'Overview'
  | 'Attendance'
  | 'Fees'
  | 'Payments'
  | 'Receipts'
  | 'Classes'
  | 'Learning'
  | 'Homework'
  | 'Quizzes'
  | 'Exams'
  | 'Results'
  | 'Progress'
  | 'Parent'
  | 'Documents'
  | 'Activity'
  | 'Audit';

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  isOpen,
  onClose,
  studentId,
  onOpenStudentQR,
  onOpenPayment,
  onOpenReceipt,
  onEditStudent,
  onSwitchStudent,
}) => {
  const { currentUser, role, isSuperAdmin, isAdmin, isStaff, isTeacher } = useAuth();
  const { settings } = useSettings();
  const [activeStudentId, setActiveStudentId] = useState<string | null>(studentId);
  const [activeTab, setActiveTab] = useState<ProfileTab>('Overview');

  // Document upload state
  const [showDocUpload, setShowDocUpload] = useState<boolean>(false);
  const [newDocTitle, setNewDocTitle] = useState<string>('');
  const [newDocCategory, setNewDocCategory] = useState<StudentDocument['category']>('ADMISSION');
  const [newDocType, setNewDocType] = useState<string>('application/pdf');

  // Class transfer state
  const [showClassTransfer, setShowClassTransfer] = useState<boolean>(false);
  const [transferTargetClassId, setTransferTargetClassId] = useState<string>('');
  const [transferReason, setTransferReason] = useState<string>('');
  const [transferFeedback, setTransferFeedback] = useState<string | null>(null);

  // Sync prop studentId if it changes
  React.useEffect(() => {
    setActiveStudentId(studentId);
  }, [studentId]);

  if (!isOpen || !activeStudentId) return null;

  const student = storageService.getStudentById(activeStudentId);
  if (!student) return null;

  // Granular RBAC Permissions
  const canAccessFinance = isSuperAdmin || isAdmin || isStaff;
  const canAccessSensitiveParent = isSuperAdmin || isAdmin || isStaff || isTeacher;
  const canEdit = isSuperAdmin || isAdmin || isStaff;

  // Retrieve records for student
  const activeQr = storageService.getActiveQRForStudent(student.studentId);
  const attendanceLogs = storageService.getAttendanceForStudent(student.studentId);
  const feeStatus: CalculatedStudentFeeStatus = storageService.calculateStudentFeeStatus(student.studentId);
  const studentFees = storageService.getFeesForStudent(student.studentId);
  const studentPayments = storageService.getPayments().filter(p => p.studentId === student.studentId);
  const studentReceipts = storageService.getReceipts().filter(r => r.studentId === student.studentId);
  const examResults = storageService.getExamResults(student.studentId);
  const homeworkList = storageService.getHomework().filter(h => h.classId === student.classId);
  const homeworkSubmissions = storageService.getHomeworkSubmissions(student.studentId);
  const quizAttempts = storageService.getQuizAttempts(student.studentId);
  const lessonProgress = storageService.getLessonProgress(student.studentId);
  const assignedClass = storageService.getClassById(student.classId);
  const auditLogs = storageService.getAuditLogs().filter(
    a => a.entityId === student.studentId || (a.details && a.details.includes(student.studentId))
  );
  const studentDocuments = storageService.getStudentDocuments(student.studentId);
  const classTransfers = storageService.getClassTransfers(student.studentId);
  const waitingListEntries = storageService.getWaitingList().filter(w => w.studentId === student.studentId);
  const allClasses = storageService.getClasses();

  // Enrolled siblings (same parent phone or name)
  const siblings = storageService.getStudents(false).filter(
    s => s.studentId !== student.studentId && (
      (s.parentPhone && s.parentPhone === student.parentPhone) ||
      (s.parentName && s.parentName.toLowerCase().trim() === student.parentName.toLowerCase().trim())
    )
  );

  // Attendance stats
  const totalAtt = attendanceLogs.length;
  const presentCount = attendanceLogs.filter(a => a.status === 'PRESENT').length;
  const lateCount = attendanceLogs.filter(a => a.status === 'LATE').length;
  const absentCount = attendanceLogs.filter(a => a.status === 'ABSENT').length;
  const excusedCount = attendanceLogs.filter(a => a.status === 'EXCUSED').length;
  const attRate = totalAtt > 0 ? Math.round(((presentCount + lateCount) / totalAtt) * 100) : 100;

  const handleDocumentUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim()) return;

    storageService.saveStudentDocument({
      studentId: student.studentId,
      studentName: student.fullName,
      title: newDocTitle.trim(),
      category: newDocCategory,
      fileUrl: newDocCategory === 'PHOTO'
        ? 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=800'
        : 'https://images.unsplash.com/photo-1568667256549-094345857637?w=800',
      fileType: newDocType,
      fileSizeKb: Math.floor(Math.random() * 400) + 120,
      uploaderId: currentUser?.userId || 'STAFF',
      uploaderName: currentUser?.name || 'Authorized Staff',
      uploaderRole: role,
    });

    setNewDocTitle('');
    setShowDocUpload(false);
  };

  const handleDocumentDelete = (docId: string) => {
    if (window.confirm('Are you sure you want to remove this verified document record?')) {
      storageService.deleteStudentDocument(docId, currentUser?.name || 'Staff');
    }
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferTargetClassId) return;

    const res = storageService.transferStudent({
      studentId: student.studentId,
      toClassId: transferTargetClassId,
      reason: transferReason || 'Academic cohort transfer',
      transferredBy: currentUser?.userId || 'SYS',
      transferredByName: currentUser?.name || 'Administrator',
      actorRole: role,
    });

    setTransferFeedback(res.message);
    setShowClassTransfer(false);
    setTransferReason('');
  };

  const tabs: { id: ProfileTab; label: string; icon: React.FC<{ className?: string }>; count?: number; locked?: boolean }[] = [
    { id: 'Overview', label: 'Overview', icon: User },
    { id: 'Attendance', label: 'Attendance', icon: CalendarCheck, count: totalAtt },
    { id: 'Fees', label: 'Fees', icon: CreditCard, locked: !canAccessFinance },
    { id: 'Payments', label: 'Payments', icon: CreditCard, count: studentPayments.length, locked: !canAccessFinance },
    { id: 'Receipts', label: 'Receipts', icon: ReceiptIcon, count: studentReceipts.length, locked: !canAccessFinance },
    { id: 'Classes', label: 'Classes', icon: Layers },
    { id: 'Learning', label: 'Learning', icon: GraduationCap, count: lessonProgress.length },
    { id: 'Homework', label: 'Homework', icon: BookOpen, count: homeworkSubmissions.length },
    { id: 'Quizzes', label: 'Quizzes', icon: HelpCircle, count: quizAttempts.length },
    { id: 'Exams', label: 'Exams', icon: Award, count: examResults.length },
    { id: 'Results', label: 'Results', icon: FileText },
    { id: 'Progress', label: 'Progress', icon: TrendingUp },
    { id: 'Parent', label: 'Parent', icon: Users, locked: !canAccessSensitiveParent },
    { id: 'Documents', label: 'Documents', icon: FolderArchive, count: studentDocuments.length },
    { id: 'Activity', label: 'Activity', icon: ActivityIcon },
    { id: 'Audit', label: 'Audit', icon: ShieldCheck, count: auditLogs.length },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-2 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-5xl max-h-[92vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Top Header Card */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160'}
              alt={student.fullName}
              className="w-13 h-13 rounded-2xl object-cover border-2 border-white dark:border-slate-700 shadow-xs"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  {student.fullName}
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  student.status === 'ACTIVE'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                }`}>
                  {student.status}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="font-mono font-bold text-blue-600">{student.studentId}</span>
                <span>&bull;</span>
                <span>{student.grade} ({student.className})</span>
                <span>&bull;</span>
                <span>{student.school}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {onOpenStudentQR && (
              <button
                onClick={() => onOpenStudentQR(student.studentId)}
                className="flex items-center gap-1.5 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 px-3 py-1.5 text-xs font-bold hover:bg-blue-100 transition"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Print QR ID</span>
              </button>
            )}
            {canEdit && onEditStudent && (
              <button
                onClick={() => {
                  onEditStudent(student);
                  onClose();
                }}
                className="rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 px-3 py-1.5 text-xs font-semibold transition"
              >
                Edit
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Ribbon */}
        <div className="flex overflow-x-auto border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 scrollbar-none">
          {tabs.map(t => {
            const Icon = t.icon;
            const isCurrent = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => {
                  if (t.locked) return;
                  setActiveTab(t.id);
                }}
                disabled={t.locked}
                className={`flex items-center gap-1.5 px-3 py-3 text-xs font-bold border-b-2 whitespace-nowrap transition ${
                  isCurrent
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : t.locked
                    ? 'border-transparent text-slate-300 dark:text-slate-600 cursor-not-allowed'
                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
                {t.count !== undefined && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                    {t.count}
                  </span>
                )}
                {t.locked && <Lock className="w-3 h-3 text-slate-400" />}
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'Overview' && (
            <div className="space-y-6">
              {/* Quick Summary Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40">
                  <span className="text-[10px] uppercase font-bold text-blue-800 dark:text-blue-300">Attendance Rate</span>
                  <p className="text-xl font-black text-blue-950 dark:text-blue-100 mt-1">{attRate}%</p>
                  <span className="text-[10px] text-slate-500">{presentCount + lateCount} / {totalAtt} Sessions</span>
                </div>
                <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40">
                  <span className="text-[10px] uppercase font-bold text-emerald-800 dark:text-emerald-300">Active QR Token</span>
                  <p className="text-xl font-black text-emerald-950 dark:text-emerald-100 mt-1">v{activeQr?.version || 1}</p>
                  <span className="text-[10px] text-slate-500">{activeQr?.scanCount || 0} Scans Recorded</span>
                </div>
                <div className="p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40">
                  <span className="text-[10px] uppercase font-bold text-amber-800 dark:text-amber-300">Fee Status</span>
                  <p className="text-lg font-black text-amber-950 dark:text-amber-100 mt-1">{feeStatus.paymentStatus}</p>
                  <span className="text-[10px] text-slate-500">Bal: Rs. {feeStatus.outstandingBalance.toLocaleString()}</span>
                </div>
                <div className="p-3.5 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/40">
                  <span className="text-[10px] uppercase font-bold text-purple-800 dark:text-purple-300">English Level</span>
                  <p className="text-xl font-black text-purple-950 dark:text-purple-100 mt-1">B2 Upper</p>
                  <span className="text-[10px] text-slate-500">CEFR Certified Track</span>
                </div>
              </div>

              {/* Student Personal & Academic Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    Personal Information
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Date of Birth</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.dob || 'N/A'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Gender</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.gender}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Phone</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.studentPhone || 'N/A'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Email</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">{student.email || 'N/A'}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Home Address</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.address || 'N/A'}</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    Academic Enrollment
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Class / Cohort</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.className}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Assigned Teacher</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{assignedClass?.teacherName || 'Master Instructor'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Schedule</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{assignedClass?.day} ({assignedClass?.startTime} - {assignedClass?.endTime})</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Registration Date</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{student.registrationDate}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Academic Notes</span>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 italic">{student.notes || 'Active English immersion student.'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Digital QR Card Banner */}
              <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white">
                      Digital QR Pass Active & Verified
                    </h5>
                    <p className="text-[11px] text-slate-500">
                      Token ID: {activeQr?.publicQrId?.slice(0, 18)}... &bull; Issued {activeQr?.issuedAt?.split('T')[0]}
                    </p>
                  </div>
                </div>

                {onOpenStudentQR && (
                  <button
                    onClick={() => onOpenStudentQR(student.studentId)}
                    className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 text-xs font-bold transition shadow-xs"
                  >
                    View & Download ID Card
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: ATTENDANCE */}
          {activeTab === 'Attendance' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">PRESENT</span>
                  <p className="text-lg font-black text-emerald-950 dark:text-emerald-200">{presentCount}</p>
                </div>
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                  <span className="text-xs font-bold text-amber-800 dark:text-amber-300">LATE</span>
                  <p className="text-lg font-black text-amber-950 dark:text-amber-200">{lateCount}</p>
                </div>
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800">
                  <span className="text-xs font-bold text-rose-800 dark:text-rose-300">ABSENT</span>
                  <p className="text-lg font-black text-rose-950 dark:text-rose-200">{absentCount}</p>
                </div>
                <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800">
                  <span className="text-xs font-bold text-blue-800 dark:text-blue-300">EXCUSED</span>
                  <p className="text-lg font-black text-blue-950 dark:text-blue-200">{excusedCount}</p>
                </div>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-400">
                      <tr>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Class / Session</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Check-in Time</th>
                        <th className="py-2.5 px-3">Method</th>
                        <th className="py-2.5 px-3">Verified By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {attendanceLogs.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-6 text-center text-slate-400">No attendance logs found.</td>
                        </tr>
                      ) : (
                        attendanceLogs.map(att => (
                          <tr key={att.attendanceId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                            <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">{att.date}</td>
                            <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{att.className}</td>
                            <td className="py-2.5 px-3">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                att.status === 'PRESENT'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : att.status === 'LATE'
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              }`}>
                                {att.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-mono text-slate-500">
                              {new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                                {att.attendanceMethod}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-500">{att.markedByName}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FEES */}
          {activeTab === 'Fees' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-blue-900 dark:text-blue-300">Total Outstanding Balance</span>
                  <p className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    LKR {feeStatus.totalOutstandingBalance.toLocaleString()}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {feeStatus.allUnpaidFeesCount} billing cycle(s) pending payment
                  </p>
                </div>

                {onOpenPayment && feeStatus.outstandingBalance > 0 && (
                  <button
                    onClick={() => {
                      const curFee = studentFees.find(f => f.feeId === feeStatus.feeId) || studentFees[0];
                      if (curFee) onOpenPayment(curFee);
                    }}
                    className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-xs font-bold transition shadow-xs"
                  >
                    Record Payment Now
                  </button>
                )}
              </div>

              <div className="space-y-2.5">
                {studentFees.map(fee => (
                  <div
                    key={fee.feeId}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-xs font-bold text-slate-900 dark:text-white">{fee.billingMonth}</h5>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          fee.status === 'PAID'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : fee.status === 'PARTIAL'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}>
                          {fee.status}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 mt-1">
                        <span>Fee: <strong>LKR {fee.amount.toLocaleString()}</strong></span>
                        <span>&bull;</span>
                        <span>Paid: <strong>LKR {fee.paidAmount.toLocaleString()}</strong></span>
                        <span>&bull;</span>
                        <span>Balance: <strong className="text-rose-600">LKR {fee.balance.toLocaleString()}</strong></span>
                        <span>&bull;</span>
                        <span>Due: {fee.dueDate}</span>
                      </div>
                    </div>

                    {fee.balance > 0 && onOpenPayment && (
                      <button
                        onClick={() => onOpenPayment(fee)}
                        className="rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-200 px-3 py-1.5 text-xs font-bold transition"
                      >
                        Pay Balance
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PAYMENTS */}
          {activeTab === 'Payments' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Payment Transactions & Receipts
              </h4>

              {studentPayments.length === 0 ? (
                <div className="p-8 text-center text-slate-400">No payment transactions recorded yet.</div>
              ) : (
                studentPayments.map(p => (
                  <div
                    key={p.paymentId}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-blue-600">{p.receiptNumber}</span>
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          LKR {p.amount.toLocaleString()}
                        </span>
                        <span className="px-2 py-0.2 rounded-md bg-slate-100 dark:bg-slate-700 text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                          {p.paymentMethod}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {p.paymentDate} &bull; Recorded by {p.recordedByName}
                      </p>
                    </div>

                    {onOpenReceipt && (
                      <button
                        onClick={() => {
                          const rcp = storageService.getReceiptById(p.receiptNumber);
                          if (rcp) onOpenReceipt(rcp);
                        }}
                        className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:underline"
                      >
                        <ReceiptIcon className="w-3.5 h-3.5" />
                        <span>View Receipt</span>
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 5: RECEIPTS */}
          {activeTab === 'Receipts' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Official Tuition Receipts
              </h4>
              {studentReceipts.map(rcp => (
                <div
                  key={rcp.receiptId}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between"
                >
                  <div>
                    <span className="font-mono font-bold text-xs text-blue-600">{rcp.receiptNumber}</span>
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                      {rcp.billingMonth} &bull; LKR {rcp.paid.toLocaleString()}
                    </p>
                    <p className="text-[11px] text-slate-400">Date: {rcp.date} &bull; {rcp.paymentMethod}</p>
                  </div>
                  {onOpenReceipt && (
                    <button
                      onClick={() => onOpenReceipt(rcp)}
                      className="rounded-xl bg-blue-600 text-white px-3 py-1.5 text-xs font-bold transition hover:bg-blue-700"
                    >
                      Print Receipt
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 6: CLASSES */}
          {activeTab === 'Classes' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Academic Class Enrollment & Cohort Details
                </h4>
                {canEdit && (
                  <button
                    onClick={() => setShowClassTransfer(prev => !prev)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold hover:bg-blue-100 transition"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>{showClassTransfer ? 'Cancel Transfer' : 'Transfer to New Class'}</span>
                  </button>
                )}
              </div>

              {transferFeedback && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 font-medium">
                  {transferFeedback}
                </div>
              )}

              {/* Class Transfer Form */}
              {showClassTransfer && (
                <form onSubmit={handleTransferSubmit} className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800/60 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-blue-900 dark:text-blue-300">
                    <ArrowRightLeft className="w-4 h-4" />
                    <span>Cohort Transfer Workflow (Preserves Past Attendance)</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">Target New Class</label>
                      <select
                        value={transferTargetClassId}
                        onChange={e => setTransferTargetClassId(e.target.value)}
                        required
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-white"
                      >
                        <option value="">Select destination class...</option>
                        {allClasses.map(c => (
                          <option key={c.classId} value={c.classId}>
                            {c.name} ({c.grade}) - {c.teacherName}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">Transfer Reason / Administrative Justification</label>
                      <input
                        type="text"
                        value={transferReason}
                        onChange={e => setTransferReason(e.target.value)}
                        placeholder="e.g. Schedule clash, student advanced level, parent request"
                        required
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-white"
                      >
                      </input>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition"
                    >
                      Execute Transfer
                    </button>
                  </div>
                </form>
              )}

              {/* Current Active Class Card */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center font-bold">
                      <School className="w-5 h-5" />
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-slate-900 dark:text-white">{assignedClass?.name || student.className}</h5>
                      <p className="text-[11px] text-slate-500">{student.grade} &bull; Room: {assignedClass?.room || 'Main Hall B'}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold">
                    PRIMARY ENROLLMENT
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs border-t border-slate-200/60 dark:border-slate-700/60">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Assigned Instructor</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{assignedClass?.teacherName || 'Academy Faculty'}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Weekly Schedule</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{assignedClass?.day || 'Saturday'} {assignedClass?.startTime || '09:00'} - {assignedClass?.endTime || '11:00'}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Class Capacity</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{assignedClass?.capacity || 25} Students</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Monthly Tuition</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">LKR {(assignedClass?.monthlyFee || 3500).toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* Waiting List Notice if applicable */}
              {waitingListEntries.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-xs">
                  <div className="flex items-center gap-2 font-bold text-amber-800 dark:text-amber-300">
                    <Clock className="w-4 h-4" />
                    <span>Active Waiting List Application</span>
                  </div>
                  <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-1">
                    Student is waitlisted for <strong>{waitingListEntries[0].preferredClassName}</strong> (Priority: {waitingListEntries[0].priority}) since {waitingListEntries[0].date}.
                  </p>
                </div>
              )}

              {/* Historical Transfers */}
              {classTransfers.length > 0 && (
                <div className="space-y-2">
                  <h5 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Past Cohort Transfer Records</h5>
                  {classTransfers.map(trf => (
                    <div key={trf.transferId} className="p-3 rounded-xl bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs flex justify-between items-center">
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">
                          From <span className="text-slate-500">{trf.fromClassName}</span> to <span className="text-blue-600 font-bold">{trf.toClassName}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {trf.transferDate} &bull; Reason: {trf.reason} &bull; By {trf.transferredByName}
                        </p>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                        AUDITED
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: LEARNING */}
          {activeTab === 'Learning' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                LMS Course Completion & Watch Progress
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {storageService.getLessons().slice(0, 6).map(lesson => {
                  const prog = lessonProgress.find(lp => lp.lessonId === lesson.lessonId);
                  const isDone = prog?.isCompleted;
                  return (
                    <div
                      key={lesson.lessonId}
                      className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[200px]">
                          {lesson.title}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isDone ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {isDone ? 'Completed' : 'In Progress'}
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 mt-2.5 overflow-hidden">
                        <div
                          className="bg-blue-600 h-1.5 rounded-full"
                          style={{ width: `${isDone ? 100 : (prog?.watchPercentage || 35)}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Watch Time: {isDone ? lesson.durationMinutes : 8} / {lesson.durationMinutes} mins
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 7: HOMEWORK */}
          {activeTab === 'Homework' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Homework Submissions & Teacher Feedback
              </h4>
              {homeworkList.map(hw => {
                const sub = homeworkSubmissions.find(s => s.homeworkId === hw.homeworkId);
                return (
                  <div
                    key={hw.homeworkId}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="text-xs font-bold text-slate-900 dark:text-white">{hw.title}</h5>
                        <p className="text-[11px] text-slate-500 mt-0.5">Due: {hw.dueDate} &bull; Max Marks: {hw.maxMarks}</p>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        sub ? (sub.marksObtained !== undefined ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800') : 'bg-amber-100 text-amber-800'
                      }`}>
                        {sub ? (sub.marksObtained !== undefined ? `Graded: ${sub.marksObtained}/${hw.maxMarks}` : 'Submitted') : 'Pending'}
                      </span>
                    </div>
                    {sub?.feedback && (
                      <p className="text-[11px] text-blue-700 dark:text-blue-300 mt-2 p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 italic">
                        Teacher Feedback: "{sub.feedback}"
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 8: QUIZZES */}
          {activeTab === 'Quizzes' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Grammar & Vocabulary Quiz History
              </h4>
              {quizAttempts.length === 0 ? (
                <div className="p-8 text-center text-slate-400">No quiz attempts logged yet.</div>
              ) : (
                quizAttempts.map(q => (
                  <div
                    key={q.attemptId}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex justify-between items-center"
                  >
                    <div>
                      <h5 className="text-xs font-bold text-slate-900 dark:text-white">Quiz Assessment ({q.quizId})</h5>
                      <p className="text-[11px] text-slate-500 mt-0.5">Score: {q.score} / {q.totalMarks} ({q.percentage}%) &bull; {q.completedAt.split('T')[0]}</p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      q.isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {q.isPassed ? 'PASSED' : 'RETRY'}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 9: EXAMS */}
          {activeTab === 'Exams' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Term Examination & Skill Performance
              </h4>
              {examResults.map(res => (
                <div
                  key={res.resultId}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h5 className="text-xs font-bold text-slate-900 dark:text-white">{res.examName}</h5>
                      <span className="text-[10px] text-slate-400">Date: {res.date}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-base font-black text-blue-600">{res.percentage}%</span>
                      <span className="ml-1.5 px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px] font-bold">
                        Grade {res.gradeLetter}
                      </span>
                    </div>
                  </div>

                  {res.skillScores && (
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs">
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Grammar</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.grammar || 85}%</p>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Vocabulary</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.vocabulary || 90}%</p>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Reading</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.reading || 88}%</p>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Writing</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.writing || 82}%</p>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Listening</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.listening || 92}%</p>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Speaking</span>
                        <p className="font-bold text-slate-900 dark:text-white">{res.skillScores.speaking || 86}%</p>
                      </div>
                    </div>
                  )}

                  {res.teacherRemarks && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 italic bg-slate-50 dark:bg-slate-900 p-2.5 rounded-xl">
                      "{res.teacherRemarks}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 11: RESULTS */}
          {activeTab === 'Results' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex justify-between items-center">
                <div>
                  <h4 className="text-sm font-bold">Academy Official Academic Transcript</h4>
                  <p className="text-xs text-blue-200 mt-0.5">Overall Rank: Top 10% &bull; GPA: 3.8 / 4.0</p>
                </div>
                <button
                  onClick={() => alert(`Generating official transcript for ${student.fullName}...`)}
                  className="flex items-center gap-1.5 rounded-xl bg-white text-blue-900 px-3.5 py-1.5 text-xs font-bold shadow-xs hover:bg-blue-50 transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Transcript</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase">Accredited Level Progress</h5>
                <p className="text-xs text-slate-500">
                  Currently pursuing CEFR B2 Upper-Intermediate certification. Eligible for Cambridge Young Learners and General English Assessment.
                </p>
              </div>
            </div>
          )}

          {/* TAB 12: PROGRESS */}
          {activeTab === 'Progress' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  English Language Skills & Academic Trajectory
                </h4>
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300">
                  Target: CEFR B2
                </span>
              </div>

              {/* Core 6 Skill Mastery Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {[
                  { skill: 'Grammar & Syntax', pct: 86, level: 'Proficient', color: 'bg-blue-600' },
                  { skill: 'Expressive Vocabulary', pct: 82, level: 'Upper-Intermediate', color: 'bg-indigo-600' },
                  { skill: 'Reading Comprehension', pct: 90, level: 'Advanced', color: 'bg-emerald-600' },
                  { skill: 'Writing & Essays', pct: 78, level: 'Intermediate', color: 'bg-amber-600' },
                  { skill: 'Listening Comprehension', pct: 88, level: 'Proficient', color: 'bg-cyan-600' },
                  { skill: 'Speaking & Pronunciation', pct: 84, level: 'Proficient', color: 'bg-purple-600' },
                ].map(item => (
                  <div key={item.skill} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                    <div className="flex justify-between items-center text-xs mb-1.5">
                      <span className="font-bold text-slate-900 dark:text-white">{item.skill}</span>
                      <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{item.pct}%</span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
                      <div className={`h-2 rounded-full ${item.color}`} style={{ width: `${item.pct}%` }} />
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 block">Level: {item.level}</span>
                  </div>
                ))}
              </div>

              {/* Key Academy Metrics Summary */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-2">
                <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase">Cumulative Academy Participation</h5>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs pt-1">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Attendance Rate</span>
                    <p className="text-sm font-black text-emerald-600 mt-0.5">{attRate}%</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Homework Submission</span>
                    <p className="text-sm font-black text-blue-600 mt-0.5">88%</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Quiz Pass Rate</span>
                    <p className="text-sm font-black text-purple-600 mt-0.5">92%</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Academic Standing</span>
                    <p className="text-sm font-black text-emerald-600 mt-0.5">Exemplary</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 13: PARENT */}
          {activeTab === 'Parent' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Parent / Guardian Information
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Parent Full Name</span>
                    <p className="font-semibold text-slate-900 dark:text-white text-sm">{student.parentName}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Relationship</span>
                    <p className="font-semibold text-slate-900 dark:text-white text-sm">{student.parentRelationship}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Phone Call</span>
                    <a
                      href={`tel:${student.parentPhone}`}
                      className="font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 mt-0.5"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>{student.parentPhone}</span>
                    </a>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">WhatsApp Direct Link</span>
                    <a
                      href={`https://wa.me/${student.whatsApp.replace(/[^0-9]/g, '')}?text=Dear%20Parent,%20this%20is%20English%20Academy%20Pro%20regarding%20${encodeURIComponent(student.fullName)}.`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-emerald-600 font-bold hover:underline flex items-center gap-1 mt-0.5"
                    >
                      <span>Open WhatsApp ({student.whatsApp})</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Emergency Contact</span>
                    <p className="font-semibold text-slate-900 dark:text-white">{student.emergencyContact || student.parentPhone}</p>
                  </div>
                </div>
              </div>

              {/* Enrolled Siblings Section */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span>Enrolled Siblings at English Academy Pro ({siblings.length})</span>
                </h4>
                {siblings.length === 0 ? (
                  <p className="text-xs text-slate-400 italic p-3 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800">
                    No other active siblings detected under this contact number.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {siblings.map(sib => (
                      <div
                        key={sib.studentId}
                        className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-2.5">
                          <img
                            src={sib.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160'}
                            alt={sib.fullName}
                            className="w-10 h-10 rounded-xl object-cover"
                          />
                          <div>
                            <h5 className="text-xs font-bold text-slate-900 dark:text-white">{sib.fullName}</h5>
                            <p className="text-[10px] text-slate-400">{sib.studentId} &bull; {sib.grade} ({sib.className})</p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setActiveStudentId(sib.studentId);
                            setActiveTab('Overview');
                            if (onSwitchStudent) onSwitchStudent(sib.studentId);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold hover:bg-blue-100 transition"
                        >
                          View Sibling
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 14: DOCUMENTS */}
          {activeTab === 'Documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Student Official Documents & Verified Records
                </h4>
                {canEdit && (
                  <button
                    onClick={() => setShowDocUpload(prev => !prev)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showDocUpload ? 'Cancel' : 'Upload Document'}</span>
                  </button>
                )}
              </div>

              {/* Upload Document Form */}
              {showDocUpload && (
                <form onSubmit={handleDocumentUpload} className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800/60 space-y-3">
                  <h5 className="text-xs font-bold text-blue-950 dark:text-blue-300">Upload New Student Record / Proof</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">Document Title</label>
                      <input
                        type="text"
                        value={newDocTitle}
                        onChange={e => setNewDocTitle(e.target.value)}
                        placeholder="e.g. Birth Certificate, GCE O/L Result Sheet"
                        required
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">Category</label>
                      <select
                        value={newDocCategory}
                        onChange={e => setNewDocCategory(e.target.value as StudentDocument['category'])}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-white"
                      >
                        <option value="ADMISSION">Admission Document</option>
                        <option value="PHOTO">Student Photo</option>
                        <option value="ID_CARD">Academy ID Card</option>
                        <option value="CERTIFICATE">Certificate / Award</option>
                        <option value="PAYMENT_PROOF">Payment Slip / Proof</option>
                        <option value="HOMEWORK">Homework File</option>
                        <option value="OTHER">Other Attachment</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">File Type</label>
                      <select
                        value={newDocType}
                        onChange={e => setNewDocType(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-white"
                      >
                        <option value="application/pdf">PDF Document (.pdf)</option>
                        <option value="image/jpeg">JPEG Image (.jpg)</option>
                        <option value="image/png">PNG Image (.png)</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition"
                    >
                      Save to Storage
                    </button>
                  </div>
                </form>
              )}

              {/* Documents List */}
              <div className="space-y-2.5">
                {studentDocuments.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">No documents uploaded for this student yet.</div>
                ) : (
                  studentDocuments.map(doc => (
                    <div
                      key={doc.documentId}
                      className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center font-bold">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 dark:text-white">{doc.title}</span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                              {doc.category}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Uploaded {doc.uploadDate} by {doc.uploaderName} ({doc.uploaderRole}) &bull; {doc.fileSizeKb} KB
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={doc.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold hover:bg-slate-50 transition"
                        >
                          <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                          <span>View File</span>
                        </a>
                        {canEdit && (
                          <button
                            onClick={() => handleDocumentDelete(doc.documentId)}
                            className="p-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                            title="Delete Document"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 15: ACTIVITY */}
          {activeTab === 'Activity' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Comprehensive Student Activity & Check-in Timeline
              </h4>
              <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-blue-200 dark:before:bg-blue-950">
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">1. Online Admission & Enrollment</h5>
                  <p className="text-[11px] text-slate-500">Registered on {student.registrationDate} into {student.grade}.</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-blue-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">2. Class Cohort Assigned</h5>
                  <p className="text-[11px] text-slate-500">Enrolled into {student.className} under {assignedClass?.teacherName || 'Academy Faculty'}.</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">3. Attendance QR Pass Issued</h5>
                  <p className="text-[11px] text-slate-500">Token hash generated & ID card prepared ({activeQr?.scanCount || 0} lifetime scans).</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-cyan-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">4. Physical Attendance Check-ins</h5>
                  <p className="text-[11px] text-slate-500">{totalAtt} total verified sessions logged with {attRate}% attendance rate.</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">5. Tuition Payments & Receipts</h5>
                  <p className="text-[11px] text-slate-500">{studentPayments.length} payment records processed with official verification receipts.</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-purple-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">6. LMS & Quiz Progress</h5>
                  <p className="text-[11px] text-slate-500">{lessonProgress.length} lesson units engaged, {quizAttempts.length} quizzes completed.</p>
                </div>
                <div className="relative">
                  <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-pink-500 border-2 border-white dark:border-slate-900" />
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">7. Examination & Certification</h5>
                  <p className="text-[11px] text-slate-500">{examResults.length} term exams completed. Academic standing: Good.</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 16: AUDIT */}
          {activeTab === 'Audit' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                System Audit Trail & Modification History ({auditLogs.length})
              </h4>
              <div className="space-y-2">
                {auditLogs.length === 0 ? (
                  <p className="text-xs text-slate-400 italic p-4 text-center">No administrative alterations logged for this student.</p>
                ) : (
                  auditLogs.map(log => (
                    <div
                      key={log.logId}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-900 dark:text-white">{log.action}</span>
                        <span className="text-[10px] text-slate-400">{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{log.details}</p>
                      <span className="text-[10px] text-blue-600 font-semibold mt-1 block">Actor: {log.actor} ({log.actorRole})</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400">
            Student records synchronized with Firestore database.
          </span>
          <button
            onClick={onClose}
            className="rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 px-4 py-1.5 font-semibold transition"
          >
            Close Profile
          </button>
        </div>
      </div>
    </div>
  );
};
