import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Printer,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  AlertCircle,
  FileText,
} from 'lucide-react';
import QRCode from 'qrcode';
import { Student, QRCodeRecord, AcademySettings } from '../types';
import { storageService } from '../services/storageService';
import { pdfService } from '../services/pdfService';
import { useSettings } from '../contexts/SettingsContext';

interface FullScreenQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentId?: string;
}

export const FullScreenQRModal: React.FC<FullScreenQRModalProps> = ({
  isOpen,
  onClose,
  studentId = 'STU-000001',
}) => {
  const { settings } = useSettings();
  const [student, setStudent] = useState<Student | null>(null);
  const [qrRecord, setQrRecord] = useState<QRCodeRecord | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [showLostCardModal, setShowLostCardModal] = useState(false);
  const [lostReason, setLostReason] = useState('');
  const [requestSent, setRequestSent] = useState(false);

  useEffect(() => {
    if (isOpen && studentId) {
      const s = storageService.getStudentById(studentId) || storageService.getStudents(false)[0];
      setStudent(s || null);

      if (s) {
        const qr = storageService.getActiveQRForStudent(s.studentId);
        setQrRecord(qr || null);

        const qrPayload = qr ? `academy://student/${qr.publicQrId}` : `academy://student/${s.studentId}`;
        QRCode.toDataURL(qrPayload, {
          width: 320,
          margin: 1,
          color: {
            dark: '#0f172a',
            light: '#ffffff',
          },
        }).then(url => setQrDataUrl(url));
      }

      // Try enabling Screen Wake Lock if available
      if ('wakeLock' in navigator) {
        try {
          (navigator as unknown as { wakeLock: { request: (type: string) => Promise<unknown> } }).wakeLock
            .request('screen')
            .catch(() => {});
        } catch {
          // ignore
        }
      }
    }
  }, [isOpen, studentId]);

  if (!isOpen || !student) return null;

  const handleDownloadPNG = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `QRCode_${student.studentId}.png`;
    a.click();
  };

  const handleDownloadIDCardPDF = async () => {
    if (!qrRecord) return;
    await pdfService.downloadStudentIDCardPDF(student, qrRecord.publicQrId, settings);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleRequestReplacement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lostReason.trim()) return;
    storageService.submitQRReplacementRequest(student.studentId, lostReason);
    setRequestSent(true);
    setTimeout(() => {
      setRequestSent(false);
      setShowLostCardModal(false);
      setLostReason('');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-4 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Official Digital Student ID
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Body */}
        <div className="p-6 flex flex-col items-center text-center space-y-4">
          {/* Academy Brand */}
          <div className="flex items-center gap-2">
            <img src={settings.logo || '/icon.svg'} alt={settings.academyName} className="w-7 h-7 rounded-lg" />
            <span className="text-sm font-extrabold text-slate-900 dark:text-white">
              {settings.academyName}
            </span>
          </div>

          {/* Student Profile Info */}
          <div className="flex items-center gap-3.5 text-left w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
            <img
              src={student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120'}
              alt={student.fullName}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-white dark:border-slate-700 shadow-sm"
            />
            <div className="overflow-hidden">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                {student.fullName}
              </h3>
              <p className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                {student.studentId}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {student.grade} &bull; {student.className}
              </p>
            </div>
          </div>

          {/* High-Contrast Large QR Container */}
          <div className="p-4 rounded-3xl bg-white shadow-lg border border-slate-200 flex flex-col items-center">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`QR code for ${student.fullName}`}
                className="w-56 h-56 object-contain"
              />
            ) : (
              <div className="w-56 h-56 bg-slate-100 animate-pulse rounded-2xl" />
            )}
            <p className="mt-2 text-[11px] font-bold text-slate-600 tracking-wider">
              TAP OR SHOW TO SCANNER
            </p>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs">
            Show this QR code at the academy entrance for attendance, exam access, and library books.
          </p>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-2 w-full pt-1">
            <button
              onClick={handleDownloadPNG}
              id="btn-download-qr-png"
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold transition"
            >
              <Download className="w-4 h-4 mb-1 text-blue-600" />
              <span>QR PNG</span>
            </button>

            <button
              onClick={handleDownloadIDCardPDF}
              id="btn-download-id-card-pdf"
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold transition"
            >
              <FileText className="w-4 h-4 mb-1 text-emerald-600" />
              <span>ID Card PDF</span>
            </button>

            <button
              onClick={handlePrint}
              id="btn-print-id-card"
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-semibold transition"
            >
              <Printer className="w-4 h-4 mb-1 text-purple-600" />
              <span>Print</span>
            </button>
          </div>

          {/* Report Lost Card Button */}
          <button
            onClick={() => setShowLostCardModal(true)}
            className="text-xs text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 flex items-center gap-1.5 transition pt-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Lost or Damaged Card? Request New QR</span>
          </button>
        </div>

        {/* Modal for Lost QR Replacement */}
        {showLostCardModal && (
          <div className="absolute inset-0 bg-white/95 dark:bg-slate-900/95 p-6 flex flex-col justify-center items-center z-10">
            <h4 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-500" />
              Request QR Card Replacement
            </h4>
            <p className="text-xs text-slate-500 text-center mt-1 max-w-xs">
              If your card is lost or damaged, submit a replacement request. Once approved, previous QR tokens will be immediately revoked.
            </p>

            {requestSent ? (
              <div className="my-6 p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold text-center">
                Replacement request submitted to Administration!
              </div>
            ) : (
              <form onSubmit={handleRequestReplacement} className="w-full mt-4 space-y-3">
                <textarea
                  value={lostReason}
                  onChange={e => setLostReason(e.target.value)}
                  placeholder="Reason (e.g., card misplaced on bus, physical damage)..."
                  required
                  rows={3}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-xs text-slate-800 dark:text-white"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowLostCardModal(false)}
                    className="flex-1 rounded-xl bg-slate-100 dark:bg-slate-800 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-blue-600 hover:bg-blue-700 py-2 text-xs font-bold text-white shadow-sm"
                  >
                    Submit Request
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
