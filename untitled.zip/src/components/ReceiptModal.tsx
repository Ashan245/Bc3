import React, { useEffect, useState } from 'react';
import {
  X,
  Download,
  Printer,
  Share2,
  CheckCircle2,
  ShieldCheck,
  Calendar,
  CreditCard,
  Building,
} from 'lucide-react';
import QRCode from 'qrcode';
import { Receipt } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { pdfService } from '../services/pdfService';
import { storageService } from '../services/storageService';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: Receipt | null;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  receipt,
}) => {
  const { settings } = useSettings();
  const [qrUrl, setQrUrl] = useState<string>('');

  useEffect(() => {
    if (isOpen && receipt) {
      const token = receipt.verificationQrToken || receipt.receiptNumber;
      QRCode.toDataURL(token, {
        width: 140,
        margin: 1,
        color: { dark: '#0f172a', light: '#ffffff' },
      }).then(url => setQrUrl(url));
    }
  }, [isOpen, receipt]);

  if (!isOpen || !receipt) return null;

  const student = storageService.getStudentById(receipt.studentId);

  const handleDownloadPDF = async () => {
    await pdfService.downloadReceiptPDF(receipt, settings);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    const url = pdfService.getWhatsAppShareUrl(
      receipt,
      student?.parentPhone || student?.studentPhone,
      settings.academyName
    );
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[94vh]">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Official Academy Receipt</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Paper Container */}
        <div id="printable-receipt-card" className="p-6 overflow-y-auto space-y-4">
          {/* Header */}
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <img src={settings.logo || '/icon.svg'} alt={settings.academyName} className="w-8 h-8 rounded-lg" />
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
                {settings.academyName}
              </h2>
            </div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              {settings.address} &bull; Tel: {settings.phone}
            </p>
            <div className="mt-3 inline-flex items-center gap-2 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 px-3 py-1 rounded-full text-xs font-bold text-blue-900 dark:text-blue-200">
              <span>Receipt No:</span>
              <strong className="tracking-wider">{receipt.receiptNumber}</strong>
            </div>
          </div>

          {/* Student & Class Meta */}
          <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Student</span>
              <p className="font-bold text-slate-900 dark:text-white truncate">{receipt.studentName}</p>
              <p className="text-[11px] text-blue-600 font-semibold">{receipt.studentId}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Class / Grade</span>
              <p className="font-bold text-slate-900 dark:text-white">{receipt.grade}</p>
              <p className="text-[11px] text-slate-500 truncate">{receipt.className}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Billing Period</span>
              <p className="font-bold text-slate-900 dark:text-white">{receipt.billingMonth}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Payment Date & Mode</span>
              <p className="font-bold text-slate-900 dark:text-white">{receipt.date} &bull; {receipt.paymentMethod}</p>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden text-xs">
            <div className="bg-slate-100 dark:bg-slate-800 px-3.5 py-2 font-bold text-slate-700 dark:text-slate-300 flex justify-between">
              <span>Description</span>
              <span>Amount (LKR)</span>
            </div>
            <div className="p-3.5 space-y-2">
              <div className="flex justify-between text-slate-800 dark:text-slate-200">
                <span>Monthly Tuition Fee</span>
                <span>Rs. {receipt.amount.toLocaleString()}</span>
              </div>
              {receipt.discount > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                  <span>Scholarship / Discount</span>
                  <span>- Rs. {receipt.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="border-t border-slate-200 dark:border-slate-800 pt-2 flex justify-between font-bold text-sm text-blue-900 dark:text-blue-100">
                <span>Amount Paid:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                  Rs. {receipt.paid.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-xs font-semibold pt-0.5">
                <span className="text-slate-500">Remaining Balance:</span>
                <span className={receipt.balance > 0 ? 'text-red-600 font-bold' : 'text-emerald-600 font-bold'}>
                  Rs. {receipt.balance.toLocaleString()} {receipt.balance === 0 ? '(PAID IN FULL)' : ''}
                </span>
              </div>
            </div>
          </div>

          {/* Verification QR & Signature */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2.5">
              {qrUrl ? (
                <img src={qrUrl} alt="Verification QR" className="w-16 h-16 rounded-xl border border-slate-200 p-1 bg-white" />
              ) : (
                <div className="w-16 h-16 bg-slate-100 rounded-xl" />
              )}
              <div className="text-[10px] text-slate-400 max-w-[140px]">
                Scan to verify receipt authenticity online.
              </div>
            </div>

            <div className="text-right text-xs">
              <span className="text-[10px] text-slate-400 block">Issued By:</span>
              <p className="font-bold text-slate-800 dark:text-slate-200">{receipt.recordedBy}</p>
              <div className="mt-3 border-b border-slate-300 dark:border-slate-700 w-32 ml-auto" />
              <span className="text-[9px] text-slate-400 block mt-0.5">Authorized Signature</span>
            </div>
          </div>

          {/* Footer Terms */}
          <p className="text-[10px] text-slate-400 text-center italic border-t border-slate-100 dark:border-slate-800 pt-3">
            {settings.receiptFooter || 'Fees once paid are non-refundable.'}
          </p>
        </div>

        {/* Action Controls */}
        <div className="px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap justify-between gap-2">
          <button
            onClick={handleShareWhatsApp}
            id="btn-receipt-whatsapp"
            className="flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 text-xs font-bold transition shadow-xs"
            title="Send receipt details to student / parent WhatsApp"
          >
            <Share2 className="w-4 h-4" />
            <span>WhatsApp</span>
          </button>

          <div className="flex gap-2">
            <button
              onClick={handlePrint}
              id="btn-receipt-print"
              className="flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-3.5 py-2 text-xs font-semibold transition"
            >
              <Printer className="w-4 h-4 text-purple-600" />
              <span>Print</span>
            </button>

            <button
              onClick={handleDownloadPDF}
              id="btn-receipt-pdf"
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-xs font-bold transition shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
