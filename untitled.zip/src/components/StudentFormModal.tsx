import React, { useState, useEffect } from 'react';
import { X, UserPlus, Save, School, Phone, User, Calendar, MapPin } from 'lucide-react';
import { Student } from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  onSaved: (saved: Student) => void;
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  onClose,
  student,
  onSaved,
}) => {
  const { role } = useAuth();
  const classes = storageService.getClasses();

  const [formData, setFormData] = useState<Partial<Student>>({
    firstName: '',
    lastName: '',
    dob: '2012-01-01',
    gender: 'MALE',
    school: '',
    grade: 'Grade 8',
    classId: classes[0]?.classId || 'CLS-G08-SAT',
    address: '',
    studentPhone: '',
    parentName: '',
    parentRelationship: 'Father',
    parentPhone: '',
    whatsApp: '',
    emergencyContact: '',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160',
    notes: '',
  });

  useEffect(() => {
    if (student) {
      setFormData(student);
    } else {
      setFormData({
        studentId: storageService.generateNextStudentId(),
        firstName: '',
        lastName: '',
        dob: '2012-01-01',
        gender: 'MALE',
        school: '',
        grade: 'Grade 8',
        classId: classes[0]?.classId || 'CLS-G08-SAT',
        address: '',
        studentPhone: '',
        parentName: '',
        parentRelationship: 'Father',
        parentPhone: '',
        whatsApp: '',
        emergencyContact: '',
        photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160',
        notes: '',
      });
    }
  }, [student, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.lastName || !formData.parentPhone) {
      alert('Please fill out all required fields.');
      return;
    }

    const assignedClass = classes.find(c => c.classId === formData.classId);
    const fullName = `${formData.firstName.trim()} ${formData.lastName.trim()}`;

    const studentToSave: Student = {
      studentId: formData.studentId || storageService.generateNextStudentId(),
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      fullName,
      dob: formData.dob || '2012-01-01',
      gender: (formData.gender as any) || 'MALE',
      school: formData.school?.trim() || 'Colombo International School',
      grade: formData.grade || 'Grade 8',
      classId: formData.classId || classes[0]?.classId || '',
      className: assignedClass?.name || formData.className || 'General Class',
      address: formData.address?.trim() || 'Colombo, Sri Lanka',
      studentPhone: formData.studentPhone?.trim() || '',
      parentName: formData.parentName?.trim() || 'Parent',
      parentRelationship: formData.parentRelationship || 'Father',
      parentPhone: formData.parentPhone.trim(),
      whatsApp: formData.whatsApp?.trim() || formData.parentPhone.trim(),
      emergencyContact: formData.emergencyContact?.trim() || formData.parentPhone.trim(),
      photo: formData.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160',
      registrationDate: formData.registrationDate || new Date().toISOString().split('T')[0],
      status: formData.status || 'ACTIVE',
      notes: formData.notes?.trim() || '',
      createdAt: formData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = storageService.saveStudent(studentToSave, role);
    onSaved(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
              {student ? <Save className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {student ? 'Edit Student Details' : 'Register New Student'}
              </h3>
              <p className="text-[11px] text-slate-500">
                Auto-provisions digital QR attendance token and profile
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                First Name *
              </label>
              <input
                type="text"
                value={formData.firstName}
                onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                required
                placeholder="e.g. Kasun"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Last Name *
              </label>
              <input
                type="text"
                value={formData.lastName}
                onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                required
                placeholder="e.g. Perera"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* DOB & Gender */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Date of Birth
              </label>
              <input
                type="date"
                value={formData.dob}
                onChange={e => setFormData({ ...formData, dob: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Gender
              </label>
              <select
                value={formData.gender}
                onChange={e => setFormData({ ...formData, gender: e.target.value as any })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
              >
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
          </div>

          {/* School & Grade & Class */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Day School *
              </label>
              <input
                type="text"
                value={formData.school}
                onChange={e => setFormData({ ...formData, school: e.target.value })}
                placeholder="e.g. Ananda College"
                required
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Grade *
              </label>
              <select
                value={formData.grade}
                onChange={e => setFormData({ ...formData, grade: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
              >
                <option value="Grade 6">Grade 6</option>
                <option value="Grade 7">Grade 7</option>
                <option value="Grade 8">Grade 8</option>
                <option value="Grade 9">Grade 9</option>
                <option value="Grade 10">Grade 10</option>
                <option value="Grade 11">Grade 11</option>
                <option value="Grade 12">Grade 12</option>
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Assigned Class Session *
              </label>
              <select
                value={formData.classId}
                onChange={e => setFormData({ ...formData, classId: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
              >
                {classes.map(c => (
                  <option key={c.classId} value={c.classId}>
                    {c.name} ({c.day} {c.startTime})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Parent Info */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 space-y-3">
            <h4 className="font-bold text-slate-900 dark:text-white text-xs">
              Parent / Guardian & Contact Details
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Parent Name *
                </label>
                <input
                  type="text"
                  value={formData.parentName}
                  onChange={e => setFormData({ ...formData, parentName: e.target.value })}
                  required
                  placeholder="e.g. Gamini Perera"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Relationship
                </label>
                <select
                  value={formData.parentRelationship}
                  onChange={e => setFormData({ ...formData, parentRelationship: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
                >
                  <option value="Father">Father</option>
                  <option value="Mother">Mother</option>
                  <option value="Guardian">Guardian</option>
                </select>
              </div>
              <div>
                <label className="font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Parent Phone / WhatsApp *
                </label>
                <input
                  type="text"
                  value={formData.parentPhone}
                  onChange={e => setFormData({ ...formData, parentPhone: e.target.value, whatsApp: e.target.value })}
                  required
                  placeholder="+94 77 123 4567"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Residential Address
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  placeholder="e.g. 42/1 Temple Road, Nugegoda"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Emergency Phone Contact
                </label>
                <input
                  type="text"
                  value={formData.emergencyContact}
                  onChange={e => setFormData({ ...formData, emergencyContact: e.target.value })}
                  placeholder="e.g. +94 11 282 3456"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
                />
              </div>
            </div>
          </div>

          {/* Photo URL & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Student Photo URL
              </label>
              <input
                type="text"
                value={formData.photo}
                onChange={e => setFormData({ ...formData, photo: e.target.value })}
                placeholder="https://..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Academic Notes & Teacher Remarks
              </label>
              <input
                type="text"
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                placeholder="e.g. Working on phonics and speech clarity"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 px-4 py-2 font-semibold text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 font-bold shadow-sm transition"
            >
              {student ? 'Save Changes' : 'Register & Issue QR Card'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
