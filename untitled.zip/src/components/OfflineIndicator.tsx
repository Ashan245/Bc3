import React, { useEffect, useState } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';

export const OfflineIndicator: React.FC<{ pendingCount?: number; onSync?: () => void }> = ({
  pendingCount = 0,
  onSync,
}) => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && pendingCount === 0) return null;

  return (
    <div
      id="pwa-offline-indicator"
      className="fixed bottom-20 md:bottom-6 right-4 z-40 flex items-center gap-2.5 rounded-xl bg-amber-500 text-white px-3.5 py-2 text-xs font-semibold shadow-xl border border-amber-400"
    >
      {!isOnline ? (
        <>
          <WifiOff className="w-4 h-4 animate-pulse" />
          <span>Offline Mode &bull; Local cache active</span>
        </>
      ) : (
        <>
          <RefreshCw className="w-4 h-4 animate-spin" />
          <span>{pendingCount} offline record{pendingCount > 1 ? 's' : ''} queued</span>
          {onSync && (
            <button
              onClick={onSync}
              className="ml-2 bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded text-[11px] underline"
            >
              Sync now
            </button>
          )}
        </>
      )}
    </div>
  );
};
