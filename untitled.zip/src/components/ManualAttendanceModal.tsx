import React, { useState, useEffect } from 'react';
import {
  X,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  UserCheck,
  Filter,
} from 'lucide-react';
import { Student, ClassSession } from '../types';
import { storageService } from '../services/storageService';
import { attendanceService, AttendanceValidationResult } from '../services/attendanceService';
import { useAuth } from '../contexts/AuthContext';

interface ManualAttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAttendanceUpdated?: () => void;
}

export const ManualAttendanceModal: React.FC<ManualAttendanceModalProps> = ({
  isOpen,
  onClose,
  onAttendanceUpdated,
}) => {
  const { currentUser, role } = useAuth();
  const [sessions, setSessions] = useState<ClassSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [result, setResult] = useState<AttendanceValidationResult | null>(null);

  useEffect(() => {
    if (isOpen) {
      const openSessions = storageService.getClassSessions().filter(s => s.status !== 'CANCELLED');
      setSessions(openSessions);
      if (openSessions.length > 0 && !selectedSessionId) {
        setSelectedSessionId(openSessions[0].sessionId);
      }
      setStudents(storageService.getStudents(false).filter(s => s.status === 'ACTIVE'));
      setResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentSession = sessions.find(s => s.sessionId === selectedSessionId);

  const filteredStudents = students.filter(s => {
    const matchQuery =
      s.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentPhone.includes(searchQuery) ||
      s.parentPhone.includes(searchQuery);
    const matchGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
    return matchQuery && matchGrade;
  });

  const handleMark = (studentId: string) => {
    if (!selectedSessionId) {
      alert('Please select an active session.');
      return;
    }

    const res = attendanceService.processAttendance({
      manualStudentId: studentId,
      sessionId: selectedSessionId,
      scannerUserId: currentUser?.userId || 'SYS',
      scannerRole: role,
      scannerName: currentUser?.name || 'Staff User',
    });

    setResult(res);
    if (onAttendanceUpdated) {
      onAttendanceUpdated();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-3 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Manual Attendance Entry (Fallback)
              </h2>
              <p className="text-[11px] text-slate-500">
                Search student by Name, ID, or Phone &bull; Uses universal attendance validator
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Active Session Selection */}
          <div className="rounded-xl bg-blue-50/80 dark:bg-blue-950/40 p-3 border border-blue-200 dark:border-blue-900/60">
            <label className="text-xs font-bold text-blue-950 dark:text-blue-200 block mb-1">
              Select Session to Mark Attendance:
            </label>
            <select
              value={selectedSessionId}
              onChange={e => setSelectedSessionId(e.target.value)}
              className="w-full rounded-xl border border-blue-300 dark:border-blue-800 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-800 dark:text-white"
            >
              {sessions.map(s => (
                <option key={s.sessionId} value={s.sessionId}>
                  {s.className} &bull; {s.date} ({s.startTime} - {s.endTime}) &bull; {s.status}
                </option>
              ))}
            </select>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search name, STU-000001, phone number..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={selectedGrade}
              onChange={e => setSelectedGrade(e.target.value)}
              className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-white"
            >
              <option value="ALL">All Grades</option>
              <option value="Grade 6">Grade 6</option>
              <option value="Grade 7">Grade 7</option>
              <option value="Grade 8">Grade 8</option>
              <option value="Grade 9">Grade 9</option>
              <option value="Grade 10">Grade 10</option>
              <option value="Grade 11">Grade 11</option>
              <option value="Grade 12">Grade 12</option>
            </select>
          </div>

          {/* Feedback Card */}
          {result && (
            <div
              className={`p-3.5 rounded-xl border text-xs ${
                result.success
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 dark:border-emerald-800'
                  : 'bg-amber-50 border-amber-300 text-amber-900 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-800'
              }`}
            >
              <div className="flex items-center gap-2 font-bold">
                {result.success ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                <span>{result.message}</span>
              </div>
              {result.feeNotice && (
                <div className="mt-1 font-semibold text-amber-700 dark:text-amber-300">
                  {result.feeNotice}
                </div>
              )}
            </div>
          )}

          {/* Student List */}
          <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
            {filteredStudents.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No students matched the search query.
              </div>
            ) : (
              filteredStudents.map(student => {
                const isAlreadyMarked = storageService
                  .getAttendance()
                  .some(a => a.studentId === student.studentId && a.sessionId === selectedSessionId);

                return (
                  <div
                    key={student.studentId}
                    className="p-3 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition text-xs"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <img
                        src={student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                        alt={student.fullName}
                        className="w-9 h-9 rounded-xl object-cover"
                      />
                      <div className="truncate">
                        <p className="font-bold text-slate-900 dark:text-white truncate">
                          {student.fullName}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {student.studentId} &bull; {student.grade} &bull; {student.parentPhone}
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      {isAlreadyMarked ? (
                        <span className="flex items-center gap-1 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2.5 py-1 text-[11px] font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Marked
                        </span>
                      ) : (
                        <button
                          onClick={() => handleMark(student.studentId)}
                          className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 text-xs font-bold transition shadow-xs"
                        >
                          Mark Present
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-800 dark:text-slate-200 px-4 py-1.5 text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
