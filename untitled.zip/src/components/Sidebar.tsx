import React from 'react';
import {
  LayoutDashboard,
  Users,
  QrCode,
  CalendarCheck,
  CreditCard,
  GraduationCap,
  BookOpen,
  Settings,
  Trash2,
  FileCheck,
  ClipboardCheck,
  User,
  HeartHandshake,
  LogOut,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQRScanner: () => void;
  onOpenStudentQR: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  onOpenQRScanner,
  onOpenStudentQR,
}) => {
  const { role, currentUser, isSuperAdmin, isAdmin, isTeacher, isStaff, isStudent, isParent, logout } = useAuth();
  const { settings, t } = useSettings();

  const handleSelect = (tabId: string) => {
    setActiveTab(tabId);
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs md:hidden transition-opacity"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col transition-transform duration-300 ease-in-out md:static md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Mobile Header in Drawer */}
        <div className="flex h-16 items-center justify-between px-4 border-b border-slate-100 dark:border-slate-800 md:hidden">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-xs">
              <img src={settings.logo || '/icon.svg'} alt={settings.academyName} className="w-full h-full object-cover" />
            </div>
            <span className="font-bold text-sm text-slate-900 dark:text-white truncate max-w-[140px]">
              {settings.academyName}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Action Buttons for Attendance & Student QR */}
        <div className="p-3 border-b border-slate-100 dark:border-slate-800 space-y-2">
          {(isSuperAdmin || isAdmin || isTeacher || isStaff) && (
            <button
              onClick={() => {
                onOpenQRScanner();
                onClose();
              }}
              id="btn-sidebar-quick-scan"
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-3 text-xs font-bold shadow-sm transition active:scale-98"
            >
              <QrCode className="w-4 h-4" />
              <span>Scan Attendance QR</span>
            </button>
          )}

          {isStudent && (
            <button
              onClick={() => {
                onOpenStudentQR();
                onClose();
              }}
              id="btn-sidebar-student-qr"
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 px-3 text-xs font-bold shadow-sm transition active:scale-98"
            >
              <QrCode className="w-4 h-4" />
              <span>Show My ID & QR</span>
            </button>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {/* Dashboard */}
          <button
            onClick={() => handleSelect('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'dashboard'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>{t.dashboard}</span>
          </button>

          {/* Student Portal (For Student Role) */}
          {isStudent && (
            <>
              <button
                onClick={() => handleSelect('student-portal')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'student-portal'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <User className="w-4 h-4 text-cyan-600" />
                <span>My Student Portal</span>
              </button>

              <button
                onClick={() => handleSelect('learning')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'learning'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <GraduationCap className="w-4 h-4 text-emerald-600" />
                <span>Lessons & LMS</span>
              </button>

              <button
                onClick={() => handleSelect('finance')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'finance'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <CreditCard className="w-4 h-4 text-amber-600" />
                <span>My Fee Receipts</span>
              </button>
            </>
          )}

          {/* Parent Portal (For Parent Role) */}
          {isParent && (
            <button
              onClick={() => handleSelect('parent-portal')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                activeTab === 'parent-portal'
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <HeartHandshake className="w-4 h-4 text-rose-600" />
              <span>Parent Portal</span>
            </button>
          )}

          {/* Admin, Staff, Teacher Main Modules */}
          {(isSuperAdmin || isAdmin || isStaff || isTeacher) && (
            <>
              {/* Students */}
              <button
                onClick={() => handleSelect('students')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'students'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>{t.students}</span>
              </button>

              {/* Attendance */}
              <button
                onClick={() => handleSelect('attendance')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'attendance'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <CalendarCheck className="w-4 h-4" />
                <span>{t.attendance}</span>
              </button>

              {/* Daily Register */}
              <button
                onClick={() => handleSelect('daily-register')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'daily-register'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <ClipboardCheck className="w-4 h-4" />
                <span>Daily Register</span>
              </button>

              {/* Learning Hub / LMS */}
              <button
                onClick={() => handleSelect('learning')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'learning'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>{t.learningHub}</span>
              </button>

              {/* Classes & Schedule */}
              <button
                onClick={() => handleSelect('classes')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'classes'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>{t.classes}</span>
              </button>
            </>
          )}

          {/* Finance (Admin, Super Admin, Staff) */}
          {(isSuperAdmin || isAdmin || isStaff) && (
            <button
              onClick={() => handleSelect('finance')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                activeTab === 'finance'
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>{t.finance}</span>
            </button>
          )}

          {/* Admissions / Public Applications */}
          {(isSuperAdmin || isAdmin) && (
            <button
              onClick={() => handleSelect('admissions')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                activeTab === 'admissions'
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              <span>Admissions</span>
            </button>
          )}

          {/* Recycle Bin (Super Admin, Admin) */}
          {(isSuperAdmin || isAdmin) && (
            <button
              onClick={() => handleSelect('recycle-bin')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                activeTab === 'recycle-bin'
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <Trash2 className="w-4 h-4 text-amber-500" />
              <span>Recycle Bin</span>
            </button>
          )}

          {/* Settings & System Audits */}
          {(isSuperAdmin || isAdmin) && (
            <button
              onClick={() => handleSelect('settings')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
                activeTab === 'settings'
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>{t.settings}</span>
            </button>
          )}
        </nav>

        {/* User Card at Bottom */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300 font-bold flex items-center justify-center text-xs shrink-0">
                {currentUser?.name?.charAt(0) || 'U'}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                  {currentUser?.name}
                </p>
                <p className="text-[10px] text-slate-400 capitalize truncate">
                  {role.replace('_', ' ')}
                </p>
              </div>
            </div>

            <button
              onClick={logout}
              className="p-1.5 text-slate-400 hover:text-red-500 transition"
              title="Sign Out / Switch"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
