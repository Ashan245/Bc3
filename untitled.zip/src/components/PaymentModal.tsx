import React, { useState } from 'react';
import {
  X,
  CreditCard,
  CheckCircle2,
  DollarSign,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { Fee, Receipt } from '../types';
import { storageService } from '../services/storageService';
import { useAuth } from '../contexts/AuthContext';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  fee: Fee | null;
  onPaymentSuccess: (receipt: Receipt) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  fee,
  onPaymentSuccess,
}) => {
  const { currentUser } = useAuth();
  if (!isOpen || !fee) return null;

  const [amount, setAmount] = useState<number>(fee.balance);
  const [discount, setDiscount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'BANK_TRANSFER' | 'CARD' | 'OTHER'>('CASH');
  const [bankSlipUrl, setBankSlipUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  const effectiveRemaining = Math.max(0, fee.balance - discount);
  const newBalance = Math.max(0, effectiveRemaining - amount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0 && discount <= 0) {
      setError('Please enter a payment amount or discount.');
      return;
    }
    if (amount > effectiveRemaining) {
      setError(`Amount cannot exceed remaining balance of Rs. ${effectiveRemaining.toLocaleString()}`);
      return;
    }

    try {
      const result = storageService.recordPayment({
        studentId: fee.studentId,
        feeId: fee.feeId,
        amount,
        discount,
        paymentMethod,
        bankSlipUrl: bankSlipUrl || undefined,
        notes: notes || undefined,
        recordedBy: currentUser?.userId || 'STAFF',
        recordedByName: currentUser?.name || 'Accounts Staff',
      });

      onPaymentSuccess(result.receipt);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error processing payment.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-3 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Record Student Fee Payment
              </h3>
              <p className="text-[11px] text-slate-500">
                Official academy receipt will be generated automatically
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Student & Fee Summary */}
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3.5 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                {fee.studentName} ({fee.studentId})
              </p>
              <p className="text-[11px] text-slate-500">
                {fee.grade} &bull; {fee.billingMonth}
              </p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Outstanding</span>
              <p className="text-sm font-extrabold text-red-600 dark:text-red-400">
                Rs. {fee.balance.toLocaleString()}
              </p>
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300 text-xs flex items-center gap-2 border border-red-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            {/* Amount */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Payment Amount (LKR) *
              </label>
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                min="0"
                max={effectiveRemaining}
                required
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-xs font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={() => setAmount(effectiveRemaining)}
                className="mt-1 text-[11px] text-blue-600 dark:text-blue-400 hover:underline font-semibold"
              >
                Pay Full Balance (Rs. {effectiveRemaining.toLocaleString()})
              </button>
            </div>

            {/* Discount */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Discount / Scholarship (LKR)
              </label>
              <input
                type="number"
                value={discount}
                onChange={e => setDiscount(Number(e.target.value))}
                min="0"
                max={fee.balance}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Payment Method *
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['CASH', 'BANK_TRANSFER', 'CARD', 'OTHER'] as const).map(method => (
                <button
                  type="button"
                  key={method}
                  onClick={() => setPaymentMethod(method)}
                  className={`p-2 rounded-xl text-xs font-bold border text-center transition ${
                    paymentMethod === method
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {method === 'BANK_TRANSFER' ? 'Bank' : method.charAt(0) + method.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>

          {/* If Bank Transfer, show slip url input */}
          {paymentMethod === 'BANK_TRANSFER' && (
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Bank Slip Reference / URL
              </label>
              <input
                type="text"
                value={bankSlipUrl}
                onChange={e => setBankSlipUrl(e.target.value)}
                placeholder="Slip No or Image URL (e.g. SLT-BOC-84920)"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
              />
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Remarks (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Paid at front desk by mother"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
            />
          </div>

          {/* New Balance Indicator */}
          <div className="rounded-xl bg-blue-50 dark:bg-blue-950/40 p-3 flex justify-between items-center text-xs">
            <span className="font-semibold text-blue-950 dark:text-blue-200">
              New Remaining Balance:
            </span>
            <span className="font-extrabold text-blue-900 dark:text-blue-100 text-sm">
              Rs. {newBalance.toLocaleString()} {newBalance === 0 ? '(CLEARED)' : ''}
            </span>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 text-xs font-bold shadow-sm transition"
            >
              Confirm & Issue Receipt
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
