import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Camera,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Zap,
  Volume2,
  VolumeX,
  Search,
  User,
  CreditCard,
  QrCode,
  CalendarCheck,
  ExternalLink,
  Phone,
  ShieldAlert,
  ArrowRight,
  RefreshCw,
  Edit3,
  Receipt as ReceiptIcon,
  Check,
  Lock,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { storageService } from '../services/storageService';
import { attendanceService, AttendanceValidationResult } from '../services/attendanceService';
import { ClassSession, Student, AttendanceStatus, Fee, Receipt } from '../types';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAttendanceUpdated?: () => void;
  onViewStudentProfile?: (studentId: string) => void;
  onOpenPayment?: (fee: Fee) => void;
  onOpenReceipt?: (receipt: Receipt) => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  isOpen,
  onClose,
  onAttendanceUpdated,
  onViewStudentProfile,
  onOpenPayment,
  onOpenReceipt,
}) => {
  const { currentUser, role, isSuperAdmin, isAdmin, isStaff, isTeacher } = useAuth();
  const [sessions, setSessions] = useState<ClassSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [registerFilter, setRegisterFilter] = useState<'ALL' | AttendanceStatus | 'UNMARKED'>('ALL');

  // Scanner & Validation States
  const [scanResult, setScanResult] = useState<AttendanceValidationResult | null>(null);
  const [fastCheckInMode, setFastCheckInMode] = useState<boolean>(false);
  const [fastCheckInBanner, setFastCheckInBanner] = useState<{
    studentId: string;
    name: string;
    status: string;
    time: string;
  } | null>(null);

  // Hardware controls
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Active view inside modal: 'SCAN' or 'REGISTER'
  const [modalView, setModalView] = useState<'SCAN' | 'REGISTER'>('SCAN');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const fastTimerRef = useRef<NodeJS.Timeout | null>(null);

  const canAccessFinance = isSuperAdmin || isAdmin || isStaff;

  const loadData = () => {
    const allSessions = storageService.getClassSessions().filter(s => s.status !== 'CANCELLED');
    setSessions(allSessions);
    if (allSessions.length > 0 && !selectedSessionId) {
      const openSession = allSessions.find(s => s.status === 'OPEN') || allSessions[0];
      setSelectedSessionId(openSession.sessionId);
    }
    setStudents(storageService.getStudents(false).filter(s => s.status === 'ACTIVE'));
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
      setScanResult(null);
      setFastCheckInBanner(null);
    }
    return () => {
      if (fastTimerRef.current) clearTimeout(fastTimerRef.current);
    };
  }, [isOpen]);

  // Audio Beep generator
  const playBeep = (isSuccess: boolean) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (isSuccess) {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.25);
      } else {
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        gain.gain.setValueAtTime(0.4, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.35);
      }
    } catch {
      // Audio context policy
    }
  };

  const toggleCamera = async () => {
    if (cameraActive) {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        videoRef.current.srcObject = null;
      }
      setCameraActive(false);
      return;
    }

    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch {
      setCameraError('Camera access denied or unavailable. Use the 1-click simulator or search.');
      setCameraActive(false);
    }
  };

  const handleScan = (payload: string, studentId?: string) => {
    if (!selectedSessionId) {
      alert('Please select an active class session first.');
      return;
    }

    const result = attendanceService.processAttendance({
      scannedPayload: payload,
      manualStudentId: studentId,
      sessionId: selectedSessionId,
      scannerUserId: currentUser?.userId || 'SYS',
      scannerRole: role,
      scannerName: currentUser?.name || 'Staff Scanner',
      isOffline: !navigator.onLine,
    });

    playBeep(result.success);

    if (fastCheckInMode && result.success && result.student && result.record) {
      // Fast check-in compact banner
      setFastCheckInBanner({
        studentId: result.student.studentId,
        name: result.student.fullName,
        status: result.status || 'PRESENT',
        time: new Date(result.record.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
      setScanResult(null);

      if (fastTimerRef.current) clearTimeout(fastTimerRef.current);
      fastTimerRef.current = setTimeout(() => {
        setFastCheckInBanner(null);
      }, 1800);
    } else {
      setScanResult(result);
      setFastCheckInBanner(null);
    }

    if (onAttendanceUpdated) {
      onAttendanceUpdated();
    }
  };

  // Quick Action override from scanner
  const handleQuickStatusChange = (newStatus: AttendanceStatus) => {
    if (!scanResult?.student || !selectedSessionId) return;

    const student = scanResult.student;
    const session = currentSession;
    if (!session) return;

    // Check if record exists
    const attendanceList = storageService.getAttendance();
    const existing = attendanceList.find(
      a => a.studentId === student.studentId && a.sessionId === selectedSessionId
    );

    if (existing) {
      storageService.updateAttendanceStatus(existing.attendanceId, newStatus, currentUser?.name || 'Teacher');
    } else {
      storageService.recordAttendance({
        studentId: student.studentId,
        studentName: student.fullName,
        classId: session.classId,
        className: session.className,
        sessionId: session.sessionId,
        date: session.date,
        status: newStatus,
        attendanceMethod: 'MANUAL_SEARCH',
        markedBy: currentUser?.userId || 'SYS',
        markedByName: currentUser?.name || 'Staff',
        markedByRole: role,
        markedAt: new Date().toISOString(),
      });
    }

    // Refresh result
    handleScan('', student.studentId);
    if (onAttendanceUpdated) onAttendanceUpdated();
  };

  if (!isOpen) return null;

  const currentSession = sessions.find(s => s.sessionId === selectedSessionId);
  const enrolledStudents = students.filter(s => s.classId === currentSession?.classId);
  const currentAttendance = storageService.getAttendance().filter(a => a.sessionId === selectedSessionId);

  // Register summary calculations
  const totalEnrolled = enrolledStudents.length;
  const presentCount = currentAttendance.filter(a => a.status === 'PRESENT').length;
  const lateCount = currentAttendance.filter(a => a.status === 'LATE').length;
  const absentCount = currentAttendance.filter(a => a.status === 'ABSENT').length;
  const excusedCount = currentAttendance.filter(a => a.status === 'EXCUSED').length;
  const unmarkedCount = Math.max(0, totalEnrolled - currentAttendance.length);

  // Filtered students for manual search and register list
  const filteredStudents = enrolledStudents.filter(s => {
    const q = searchQuery.toLowerCase();
    const matchesQuery = s.fullName.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q) || s.studentPhone.includes(q);
    if (!matchesQuery) return false;

    if (registerFilter === 'ALL') return true;
    const att = currentAttendance.find(a => a.studentId === s.studentId);
    if (registerFilter === 'UNMARKED') return !att;
    return att?.status === registerFilter;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-2 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-4xl max-h-[94vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Top App Header */}
        <div className="flex flex-wrap items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-xs">
              <QrCode className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>Student Check-in & Register</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-bold">
                  PRO
                </span>
              </h2>
              <p className="text-[11px] text-slate-500">
                Instant identity resolution &bull; Real-time fee status &bull; Class register
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Fast Check-in Mode Toggle */}
            <div
              onClick={() => setFastCheckInMode(!fastCheckInMode)}
              className={`cursor-pointer flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition border select-none ${
                fastCheckInMode
                  ? 'bg-amber-100 border-amber-300 text-amber-900 dark:bg-amber-950/70 dark:border-amber-700 dark:text-amber-200'
                  : 'bg-slate-100 border-slate-200 text-slate-600 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300'
              }`}
              title="Toggle Fast Check-in Mode (rapid scanning without full profile popups)"
            >
              <Zap className={`w-3.5 h-3.5 ${fastCheckInMode ? 'text-amber-600' : 'text-slate-400'}`} />
              <span>Fast Mode: {fastCheckInMode ? 'ON' : 'OFF'}</span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-1.5 rounded-xl text-slate-500 hover:bg-slate-200 dark:text-slate-400 dark:hover:bg-slate-800 transition"
              title={soundEnabled ? 'Mute Audio' : 'Enable Beep Audio'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-blue-600" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              onClick={() => {
                if (cameraActive && videoRef.current?.srcObject) {
                  (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
                }
                onClose();
              }}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Switcher: Scanner View vs Today's Register */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-5">
          <button
            onClick={() => setModalView('SCAN')}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
              modalView === 'SCAN'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>QR Check-in Scanner</span>
          </button>
          <button
            onClick={() => setModalView('REGISTER')}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
              modalView === 'REGISTER'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <CalendarCheck className="w-3.5 h-3.5" />
            <span>Today's Register ({currentAttendance.length}/{totalEnrolled})</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Active Class & Session Selector Ribbon */}
          <div className="rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 p-3.5 border border-blue-200 dark:border-blue-900/50">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div>
                <label className="text-xs font-bold text-blue-950 dark:text-blue-200 flex items-center gap-1.5">
                  <span>Active Class Session:</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-200 text-blue-900 dark:bg-blue-900 dark:text-blue-200 font-extrabold">
                    {currentSession?.status || 'OPEN'}
                  </span>
                </label>
                <p className="text-[11px] text-blue-700 dark:text-blue-300">
                  {currentSession ? `${currentSession.className} &bull; Room: ${currentSession.room} &bull; Teacher: ${currentSession.teacherName}` : 'Select a session'}
                </p>
              </div>

              <select
                value={selectedSessionId}
                onChange={e => {
                  setSelectedSessionId(e.target.value);
                  setScanResult(null);
                }}
                className="rounded-xl border border-blue-300 dark:border-blue-800 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-white shadow-xs focus:ring-2 focus:ring-blue-500"
              >
                {sessions.map(s => (
                  <option key={s.sessionId} value={s.sessionId}>
                    {s.className} ({s.date} {s.startTime}-{s.endTime})
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Session Stats Bar */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-3 pt-2.5 border-t border-blue-200/60 dark:border-blue-900/40 text-center">
              <div>
                <span className="text-[9px] uppercase font-bold text-slate-500 dark:text-slate-400">Enrolled</span>
                <p className="text-xs font-black text-slate-900 dark:text-white">{totalEnrolled}</p>
              </div>
              <div>
                <span className="text-[9px] uppercase font-bold text-emerald-600 dark:text-emerald-400">Present</span>
                <p className="text-xs font-black text-emerald-700 dark:text-emerald-300">{presentCount}</p>
              </div>
              <div>
                <span className="text-[9px] uppercase font-bold text-amber-600 dark:text-amber-400">Late</span>
                <p className="text-xs font-black text-amber-700 dark:text-amber-300">{lateCount}</p>
              </div>
              <div>
                <span className="text-[9px] uppercase font-bold text-rose-600 dark:text-rose-400">Absent</span>
                <p className="text-xs font-black text-rose-700 dark:text-rose-300">{absentCount}</p>
              </div>
              <div>
                <span className="text-[9px] uppercase font-bold text-blue-600 dark:text-blue-400">Excused</span>
                <p className="text-xs font-black text-blue-700 dark:text-blue-300">{excusedCount}</p>
              </div>
              <div>
                <span className="text-[9px] uppercase font-bold text-slate-400">Unmarked</span>
                <p className="text-xs font-black text-slate-700 dark:text-slate-300">{unmarkedCount}</p>
              </div>
            </div>
          </div>

          {/* FAST CHECK-IN CONFIRMATION BANNER */}
          {fastCheckInBanner && (
            <div className="p-4 rounded-2xl bg-emerald-600 text-white shadow-lg flex items-center justify-between animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-7 h-7 shrink-0" />
                <div>
                  <h4 className="text-sm font-black">
                    ✓ ATTENDANCE RECORDED: {fastCheckInBanner.studentId} - {fastCheckInBanner.name}
                  </h4>
                  <p className="text-xs text-emerald-100">
                    Marked as {fastCheckInBanner.status} at {fastCheckInBanner.time}. Ready for next scan...
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-700">FAST MODE</span>
            </div>
          )}

          {/* VIEW: SCANNER MODE */}
          {modalView === 'SCAN' && (
            <div className="space-y-4">
              {/* Camera Scanner Viewport */}
              <div className="relative rounded-3xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col items-center justify-center min-h-[170px]">
                {cameraActive ? (
                  <div className="relative w-full h-56 bg-black flex items-center justify-center">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="w-44 h-44 border-2 border-blue-500/80 rounded-2xl relative animate-pulse">
                        <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-blue-400 -mt-1 -ml-1" />
                        <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-blue-400 -mt-1 -mr-1" />
                        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-blue-400 -mb-1 -ml-1" />
                        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-blue-400 -mb-1 -mr-1" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 text-center text-slate-400">
                    <Camera className="w-8 h-8 mx-auto text-slate-600 mb-1.5" />
                    <p className="text-xs text-slate-300 font-semibold">Camera Scanner Standby</p>
                    <p className="text-[11px] text-slate-500 max-w-sm mt-0.5">
                      Point camera at student QR card or use the instant simulator / search below.
                    </p>
                    <button
                      onClick={toggleCamera}
                      id="btn-toggle-camera"
                      className="mt-2.5 inline-flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 text-xs font-bold transition shadow-xs"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Start Device Camera</span>
                    </button>
                  </div>
                )}

                {cameraError && (
                  <div className="absolute bottom-2 inset-x-2 bg-rose-950/90 border border-rose-800 text-rose-200 text-[11px] p-2 rounded-xl text-center">
                    {cameraError}
                  </div>
                )}
              </div>

              {/* COMPREHENSIVE STUDENT CHECK-IN CARD (Requirement 1 & 2) */}
              {scanResult && (
                <div
                  id="student-check-in-card"
                  className={`rounded-3xl p-5 border transition-all animate-in fade-in zoom-in-95 ${
                    scanResult.success
                      ? 'bg-emerald-50/50 border-emerald-300 dark:bg-emerald-950/30 dark:border-emerald-800'
                      : scanResult.resultCode === 'DUPLICATE'
                      ? 'bg-amber-50/50 border-amber-300 dark:bg-amber-950/30 dark:border-amber-800'
                      : 'bg-rose-50/50 border-rose-300 dark:bg-rose-950/30 dark:border-rose-800'
                  }`}
                >
                  {/* Status Banner */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      {scanResult.success ? (
                        <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                      ) : scanResult.resultCode === 'DUPLICATE' ? (
                        <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
                      ) : (
                        <XCircle className="w-6 h-6 text-rose-600 shrink-0" />
                      )}

                      <div>
                        <h3 className="text-sm font-black text-slate-900 dark:text-white">
                          {scanResult.success
                            ? 'STUDENT CHECK-IN VERIFIED'
                            : scanResult.resultCode === 'DUPLICATE'
                            ? 'ATTENDANCE ALREADY RECORDED'
                            : scanResult.resultCode === 'WRONG_CLASS'
                            ? 'WRONG CLASS: ACCESS REJECTED'
                            : 'CHECK-IN VALIDATION FAILED'}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                          {scanResult.message}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => setScanResult(null)}
                      className="rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-3 py-1 text-xs font-bold border border-slate-200 dark:border-slate-700 shadow-xs transition"
                    >
                      Next Student
                    </button>
                  </div>

                  {/* Student Identity Card */}
                  {scanResult.student && (
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Left: Photo & Basic Identity */}
                      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={scanResult.student.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160'}
                            alt={scanResult.student.fullName}
                            className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500 shadow-sm"
                          />
                          <div>
                            <h4 className="text-sm font-black text-slate-900 dark:text-white">
                              {scanResult.student.fullName}
                            </h4>
                            <p className="font-mono font-bold text-xs text-blue-600">
                              {scanResult.student.studentId}
                            </p>
                            <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              scanResult.student.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            }`}>
                              {scanResult.student.status}
                            </span>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-300">
                          <div>Grade: <strong className="text-slate-900 dark:text-white">{scanResult.student.grade}</strong></div>
                          <div>Class: <strong className="text-slate-900 dark:text-white">{scanResult.student.className}</strong></div>
                          <div>School: <strong className="text-slate-900 dark:text-white">{scanResult.student.school}</strong></div>
                          <div>Enrolled Since: {scanResult.student.registrationDate}</div>
                        </div>

                        {/* Full Student Profile Button (Requirement 8) */}
                        {onViewStudentProfile && (
                          <button
                            onClick={() => {
                              if (scanResult.student) {
                                onViewStudentProfile(scanResult.student.studentId);
                              }
                            }}
                            id="btn-view-full-profile"
                            className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 text-xs font-bold transition shadow-xs active:scale-98"
                          >
                            <User className="w-3.5 h-3.5" />
                            <span>VIEW FULL PROFILE</span>
                          </button>
                        )}
                      </div>

                      {/* Center: Today's Attendance & Quick Actions */}
                      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                        <span className="text-[10px] uppercase font-bold text-slate-400">
                          Today's Session Attendance
                        </span>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-500">Status:</span>
                          <span className={`px-2.5 py-1 rounded-full text-xs font-black ${
                            scanResult.status === 'PRESENT' || scanResult.alreadyRecorded?.status === 'PRESENT'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : scanResult.status === 'LATE' || scanResult.alreadyRecorded?.status === 'LATE'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}>
                            {scanResult.status || scanResult.alreadyRecorded?.status || 'REJECTED'}
                          </span>
                        </div>

                        <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                          <div>Check-in Time: <strong className="text-slate-900 dark:text-white">
                            {scanResult.record
                              ? new Date(scanResult.record.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                              : scanResult.alreadyRecorded
                              ? new Date(scanResult.alreadyRecorded.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                              : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </strong></div>
                          <div>Method: <strong className="text-slate-900 dark:text-white">{scanResult.record?.attendanceMethod || scanResult.alreadyRecorded?.attendanceMethod || 'QR'}</strong></div>
                          <div>Verified By: <strong className="text-slate-900 dark:text-white">{scanResult.record?.markedByName || scanResult.alreadyRecorded?.markedByName || currentUser?.name}</strong></div>
                        </div>

                        {/* Quick Role-Based Attendance Actions */}
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">
                            Quick Status Adjustment
                          </span>
                          <div className="grid grid-cols-3 gap-1.5 text-xs">
                            <button
                              onClick={() => handleQuickStatusChange('PRESENT')}
                              className="py-1 px-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-200 text-[11px] font-bold transition text-center"
                            >
                              Present
                            </button>
                            <button
                              onClick={() => handleQuickStatusChange('LATE')}
                              className="py-1 px-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-200 text-[11px] font-bold transition text-center"
                            >
                              Late
                            </button>
                            <button
                              onClick={() => handleQuickStatusChange('EXCUSED')}
                              className="py-1 px-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-200 text-[11px] font-bold transition text-center"
                            >
                              Excused
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Right: Real Fee Status (Requirement 2 & 24) */}
                      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-bold text-slate-400">
                            Fee & Payment Status
                          </span>
                          {!canAccessFinance && (
                            <span className="flex items-center gap-1 text-[10px] text-slate-400">
                              <Lock className="w-3 h-3" />
                              <span>Restricted</span>
                            </span>
                          )}
                        </div>

                        {!canAccessFinance ? (
                          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-center text-slate-500 text-xs">
                            <Lock className="w-5 h-5 mx-auto text-slate-400 mb-1" />
                            <p className="font-semibold text-slate-700 dark:text-slate-300">
                              Fee details restricted to finance staff
                            </p>
                            <span className="text-[10px] text-slate-400">
                              Teacher attendance validation active.
                            </span>
                          </div>
                        ) : scanResult.feeStatus ? (
                          <div className="space-y-2 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">Billing Month:</span>
                              <strong className="text-slate-900 dark:text-white">{scanResult.feeStatus.billingMonth}</strong>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">Status:</span>
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                                scanResult.feeStatus.paymentStatus === 'PAID'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : scanResult.feeStatus.paymentStatus === 'PARTIAL'
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              }`}>
                                {scanResult.feeStatus.paymentStatus}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">Outstanding Bal:</span>
                              <strong className="text-rose-600 font-mono text-sm">
                                LKR {scanResult.feeStatus.outstandingBalance.toLocaleString()}
                              </strong>
                            </div>

                            {scanResult.feeStatus.lastPaymentDate && (
                              <div className="text-[11px] text-slate-500">
                                Last Payment: LKR {scanResult.feeStatus.lastPaymentAmount?.toLocaleString()} ({scanResult.feeStatus.lastPaymentDate})
                              </div>
                            )}

                            {/* Non-blocking Warning Banner if overdue / unpaid */}
                            {(scanResult.feeStatus.paymentStatus === 'OVERDUE' || scanResult.feeStatus.paymentStatus === 'UNPAID') && (
                              <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 text-amber-900 dark:text-amber-200 text-[11px] font-semibold flex items-center gap-1.5">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                <span>Outstanding fee: LKR {scanResult.feeStatus.outstandingBalance.toLocaleString()} (Attendance allowed)</span>
                              </div>
                            )}

                            {/* Fee Actions */}
                            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                              {onOpenPayment && scanResult.feeStatus.outstandingBalance > 0 && (
                                <button
                                  onClick={() => {
                                    const feeObj = storageService.getFeesForStudent(scanResult.student!.studentId)[0];
                                    if (feeObj) onOpenPayment(feeObj);
                                  }}
                                  className="flex-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white py-1.5 px-2 text-[11px] font-bold transition text-center shadow-xs"
                                >
                                  Add Payment
                                </button>
                              )}
                              {onViewStudentProfile && (
                                <button
                                  onClick={() => onViewStudentProfile(scanResult.student!.studentId)}
                                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 py-1.5 px-2 text-[11px] font-bold transition"
                                >
                                  Receipts
                                </button>
                              )}
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Instant Manual Search & Student Simulator */}
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-4 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Search className="w-3.5 h-3.5 text-blue-600" />
                    <span>Instant Student Attendance Search & Simulator</span>
                  </span>
                  <span className="text-[10px] text-slate-500">
                    Search or click any student to test validation
                  </span>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search by student name, ID (e.g. STU-000101), or phone..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                  {students.slice(0, 8).map(s => {
                    const qr = storageService.getActiveQRForStudent(s.studentId);
                    const att = currentAttendance.find(a => a.studentId === s.studentId);
                    return (
                      <div
                        key={s.studentId}
                        className="flex items-center justify-between p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 transition text-xs"
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <img
                            src={s.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                            alt={s.fullName}
                            className="w-7 h-7 rounded-lg object-cover"
                          />
                          <div className="truncate">
                            <p className="font-bold text-slate-800 dark:text-slate-200 truncate">
                              {s.fullName}
                            </p>
                            <p className="text-[10px] text-slate-400">
                              {s.studentId} &bull; {s.className}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0 ml-2">
                          {att && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              {att.status}
                            </span>
                          )}
                          <button
                            onClick={() => handleScan(qr?.publicQrId || '', s.studentId)}
                            className="rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 px-2 py-1 text-[11px] font-bold transition"
                          >
                            Scan
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* VIEW: TODAY'S LIVE REGISTER (Requirement 4, 11, 13) */}
          {modalView === 'REGISTER' && (
            <div className="space-y-3">
              {/* Register Filter Ribbon */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  {(['ALL', 'PRESENT', 'LATE', 'ABSENT', 'EXCUSED', 'UNMARKED'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setRegisterFilter(f)}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                        registerFilter === f
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search register..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Student Register Table */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-400">
                      <tr>
                        <th className="py-2.5 px-3">Student</th>
                        <th className="py-2.5 px-3">Student ID</th>
                        <th className="py-2.5 px-3">Attendance</th>
                        <th className="py-2.5 px-3">Time</th>
                        <th className="py-2.5 px-3">Method</th>
                        {canAccessFinance && <th className="py-2.5 px-3">Fee Status</th>}
                        <th className="py-2.5 px-3 text-right">Quick Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredStudents.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-slate-400">
                            No students match the selected filter.
                          </td>
                        </tr>
                      ) : (
                        filteredStudents.map(s => {
                          const att = currentAttendance.find(a => a.studentId === s.studentId);
                          const feeStatus = canAccessFinance ? storageService.calculateStudentFeeStatus(s.studentId) : null;
                          const qr = storageService.getActiveQRForStudent(s.studentId);

                          return (
                            <tr key={s.studentId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                              <td className="py-2.5 px-3">
                                <div className="flex items-center gap-2">
                                  <img
                                    src={s.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                                    alt={s.fullName}
                                    className="w-7 h-7 rounded-lg object-cover"
                                  />
                                  <span className="font-bold text-slate-900 dark:text-white">
                                    {s.fullName}
                                  </span>
                                </div>
                              </td>
                              <td className="py-2.5 px-3 font-mono font-semibold text-blue-600">
                                {s.studentId}
                              </td>
                              <td className="py-2.5 px-3">
                                {att ? (
                                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    att.status === 'PRESENT'
                                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                      : att.status === 'LATE'
                                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                      : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  }`}>
                                    {att.status}
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 dark:bg-slate-800">
                                    NOT MARKED
                                  </span>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-slate-500 font-mono">
                                {att ? new Date(att.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-[10px] text-slate-500 font-semibold">
                                  {att?.attendanceMethod || '-'}
                                </span>
                              </td>
                              {canAccessFinance && (
                                <td className="py-2.5 px-3">
                                  {feeStatus ? (
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      feeStatus.paymentStatus === 'PAID'
                                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                        : feeStatus.paymentStatus === 'PARTIAL'
                                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                        : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                    }`}>
                                      {feeStatus.paymentStatus}
                                    </span>
                                  ) : '-'}
                                </td>
                              )}
                              <td className="py-2.5 px-3 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => handleScan(qr?.publicQrId || '', s.studentId)}
                                    className="rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 px-2 py-1 text-[11px] font-bold transition"
                                  >
                                    Check-in
                                  </button>
                                  {onViewStudentProfile && (
                                    <button
                                      onClick={() => onViewStudentProfile(s.studentId)}
                                      className="rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 px-2 py-1 text-[11px] font-bold transition"
                                    >
                                      Profile
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap items-center justify-between text-xs gap-2">
          <span className="text-slate-500 text-[11px]">
            Check-ins recorded directly to Firestore database. Duplicate and wrong class protection active.
          </span>
          <button
            onClick={() => {
              if (cameraActive && videoRef.current?.srcObject) {
                (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
              }
              onClose();
            }}
            className="rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 px-4 py-1.5 font-bold transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
