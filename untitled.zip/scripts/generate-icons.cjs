const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Generate a valid PNG buffer
function createSolidPNG(width, height, r, g, b) {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crc = crc32(Buffer.concat([typeBuf, data]));
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc, 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  function crc32(buf) {
    let table = [];
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[i] = c >>> 0;
    }
    let crc = 0 ^ (-1);
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ (-1)) >>> 0;
  }

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // RGB
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace
  const ihdrChunk = chunk('IHDR', ihdr);

  // Raw image data with filter byte 0 at start of each scanline
  const rowLen = 1 + width * 3;
  const rawData = Buffer.alloc(rowLen * height);
  for (let y = 0; y < height; y++) {
    const rowStart = y * rowLen;
    rawData[rowStart] = 0; // filter None
    for (let x = 0; x < width; x++) {
      const px = rowStart + 1 + x * 3;
      // create slight gradient
      const factor = (x + y) / (width + height);
      rawData[px] = Math.floor(r * (0.8 + 0.4 * factor));
      rawData[px + 1] = Math.floor(g * (0.8 + 0.4 * factor));
      rawData[px + 2] = Math.floor(b * (0.8 + 0.4 * factor));
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idatChunk = chunk('IDAT', compressed);
  const iendChunk = chunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const pub = path.join(__dirname, '..', 'public');
const png192 = createSolidPNG(192, 192, 30, 58, 138);
const png512 = createSolidPNG(512, 512, 30, 58, 138);

fs.writeFileSync(path.join(pub, 'apple-touch-icon.png'), png192);
fs.writeFileSync(path.join(pub, 'pwa-192x192.png'), png192);
fs.writeFileSync(path.join(pub, 'pwa-512x512.png'), png512);
fs.writeFileSync(path.join(pub, 'pwa-maskable-512x512.png'), png512);
console.log('PNG icons created successfully');
